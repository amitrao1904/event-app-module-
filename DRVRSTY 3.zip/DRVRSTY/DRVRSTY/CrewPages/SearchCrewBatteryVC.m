//
//  SearchCrewBatteryVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 05/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SearchCrewBatteryVC.h"
#import "CustomSearchBatteryCell.h"
@interface SearchCrewBatteryVC ()
{
    CustomSearchBatteryCell *prototypeCell;
    
}

@end

@implementation SearchCrewBatteryVC
@synthesize tbl_new;
- (void)viewDidLoad {
    [super viewDidLoad];
    array_list=[[NSMutableArray alloc]init];
    array_list1=[[NSMutableArray alloc]init];
    array_list2=[[NSMutableArray alloc]init];
    array_list3=[[NSMutableArray alloc]init];
    array_list4=[[NSMutableArray alloc]init];
    
    [array_list addObject:@"1"];
    [array_list addObject:@"2"];
    [array_list addObject:@"1"];
    
    [array_list1 addObject:@"Friday Night Cruise"];
    [array_list1 addObject:@"Meetup"];
    [array_list1 addObject:@"Weekend Cruise"];
    
    [array_list2 addObject:@"Today at 8:00PM"];
    [array_list2 addObject:@"10 March at 5:30PM"];
    [array_list2 addObject:@"17 March at 3:00PM"];
    
    [array_list3 addObject:[UIImage imageNamed:@"going-icon"]];
    [array_list3 addObject:[UIImage imageNamed:@"maybe-icon"]];
    [array_list3 addObject:[UIImage imageNamed:@"going-icon"]];
    
    [array_list4 addObject:@"1"];
    [array_list4 addObject:@"2"];
    [array_list4 addObject:@"3"];

    
    
    
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods




#pragma mark - Action Method
-(IBAction)menu_Action:(id)sender
{
   [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)chat_Action:(id)sender
{
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
    
}

-(IBAction)user_Action:(id)sender
{
    
    SearchFollowVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchFollowVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
-(IBAction)crew_Action:(id)sender
{
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomSearchBatteryCell *)[tbl_new dequeueReusableCellWithIdentifier:NSStringFromClass([CustomSearchBatteryCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[CustomSearchBatteryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([CustomSearchBatteryCell class])];
    }
    
    NSString *str1=[array_list objectAtIndex:indexPath.row];
    
    prototypeCell.label1.text=[array_list1 objectAtIndex:indexPath.row];
    prototypeCell.label2.text=[array_list2 objectAtIndex:indexPath.row];
    
    if ([str1 isEqualToString:@"1"]) {
        
        
        [prototypeCell.btn_btry setImage:[UIImage imageNamed:@"going-icon"] forState:UIControlStateNormal];
        
    }
    else
    {
    
        [prototypeCell.btn_btry setImage:[UIImage imageNamed:@"maybe-icon"] forState:UIControlStateNormal];
        
    
    }
    
    return prototypeCell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *str1=[array_list4 objectAtIndex:indexPath.row];
    
    
    if ([str1 isEqualToString:@"1"])
    {
        DRVEventDetaIlVC1 *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventDetaIlVC1"];
        [self.navigationController pushViewController:registercontroller animated:true];
    }
    if ([str1 isEqualToString:@"2"])
    {
        DRVEventDetaIlVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventDetaIlVC"];
        [self.navigationController pushViewController:registercontroller animated:true];
    }
    if ([str1 isEqualToString:@"3"])
    {
        DRVEventDetaIlVC2 *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventDetaIlVC2"];
        [self.navigationController pushViewController:registercontroller animated:true];
    }
    
    
}

#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

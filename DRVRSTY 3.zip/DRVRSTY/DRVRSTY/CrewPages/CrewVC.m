//
//  CrewVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CrewVC.h"

@interface CrewVC ()

@end

@implementation CrewVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method


#pragma mark - API Methods



#pragma mark - Action Method
- (IBAction)menu_Action:(id)sender
{
    
    DRVSetting1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting1VC"];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController pushViewController:addinvController animated:NO];
    
    
}
- (IBAction)createcrew_Action:(id)sender
{
    CreateCrewVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CreateCrewVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)searchcrew_Action:(id)sender
{
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}

- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

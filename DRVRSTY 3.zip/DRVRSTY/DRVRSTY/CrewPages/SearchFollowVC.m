//
//  SearchFollowVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 05/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SearchFollowVC.h"
#import "CustomSearchFollowCell.h"
@interface SearchFollowVC ()
{
    CustomSearchFollowCell *prototypeCell;
    
}
@end

@implementation SearchFollowVC
@synthesize tbl_new;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    array_list=[[NSMutableArray alloc]init];
    
    [array_list addObject:@"1"];
    [array_list addObject:@"2"];
    [array_list addObject:@"1"];
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method




#pragma mark - API Methods




#pragma mark - Action Method
-(IBAction)menu_Action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)chat_Action:(id)sender
{
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
    
}

-(IBAction)event_Action:(id)sender
{
    
    SearchCrewBatteryVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchCrewBatteryVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
-(IBAction)crew_Action:(id)sender
{
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomSearchFollowCell *)[tbl_new dequeueReusableCellWithIdentifier:NSStringFromClass([CustomSearchFollowCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[CustomSearchFollowCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([CustomSearchFollowCell class])];
    }
    NSString *str=[array_list objectAtIndex:indexPath.row];
    
    
    if ([str isEqualToString:@"1"]) {
        
       
        
        
        prototypeCell.btn_followUnfollow.layer.backgroundColor = [UIColor whiteColor].CGColor;
        [prototypeCell.btn_followUnfollow setTitle:@"Follow" forState:UIControlStateNormal];
        [prototypeCell.btn_followUnfollow setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        
    }
    else
    {
        
        prototypeCell.btn_followUnfollow.layer.cornerRadius=0;
        prototypeCell.btn_followUnfollow.layer.masksToBounds=YES;
        prototypeCell.btn_followUnfollow.layer.borderWidth = 1;
        prototypeCell.btn_followUnfollow.layer.borderColor = [UIColor whiteColor].CGColor;
        
        [prototypeCell.btn_followUnfollow setTitle:@"Unfollow" forState:UIControlStateNormal];
        prototypeCell.btn_followUnfollow.layer.backgroundColor = [UIColor clearColor].CGColor;
        [prototypeCell.btn_followUnfollow setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        
    }

    return prototypeCell;
}


#pragma mark - Memory CleanUP

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

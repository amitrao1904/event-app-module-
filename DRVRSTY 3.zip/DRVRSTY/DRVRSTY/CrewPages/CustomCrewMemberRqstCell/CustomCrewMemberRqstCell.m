//
//  CustomCrewMemberRqstCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 05/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomCrewMemberRqstCell.h"

@implementation CustomCrewMemberRqstCell
@synthesize label1,label2,btn_accept,btn_decline,imageinvite;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  DRVCustomCrewBlockedCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 09/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVCustomCrewBlockedCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *btn_block;
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UIButton *btn_label2;
@property (weak, nonatomic) IBOutlet UIImageView *imageinvite;
@end

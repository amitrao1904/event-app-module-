//
//  DRVCustomCrewBlockedCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 09/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCustomCrewBlockedCell.h"

@implementation DRVCustomCrewBlockedCell
@synthesize btn_block,label1,btn_label2,imageinvite;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  CrewTimelineVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CrewTimelineVC : UIViewController<UITableViewDelegate,UITableViewDataSource,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate, UIActionSheetDelegate,UIScrollViewDelegate,UIDocumentInteractionControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    NSMutableArray *array_list;
    
    BOOL imageflag;
    UIImage *finalImage;
    NSData *dataImage;
    IBOutlet UIButton *postImage;
    NSData *imageData;
    NSData *eventImageData1;
    
}
@property (strong, nonatomic) IBOutlet UITableView *tbl_new;

@property (weak, nonatomic) IBOutlet UIButton *btn_about;
@property (weak, nonatomic) IBOutlet UIButton *btn_options;
@property (weak, nonatomic) IBOutlet UITextField *txt_search;
@property (strong, nonatomic) IBOutlet UIImageView *imageview1;

@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;




@end

//
//  SendInviteVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendInviteVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    
    NSMutableArray *array_list1;

}
@property (strong, nonatomic) IBOutlet UITableView *tbl_new;
@property (weak, nonatomic) IBOutlet UITextField *txt_search;
@property (weak, nonatomic) IBOutlet UIButton *btn_skip;




@end

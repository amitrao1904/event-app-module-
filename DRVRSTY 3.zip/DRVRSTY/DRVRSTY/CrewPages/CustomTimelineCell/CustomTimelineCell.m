//
//  CustomTimelineCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomTimelineCell.h"

@implementation CustomTimelineCell
@synthesize label1,label2,imageinvite,btn_arrow,btn_sc,btn_hrs,btn_comments;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

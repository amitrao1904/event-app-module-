//
//  CustomTimelineCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTimelineCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UIImageView *imageinvite;
@property (weak, nonatomic) IBOutlet UIButton *btn_arrow;
@property (weak, nonatomic) IBOutlet UIButton *btn_hrs;
@property (weak, nonatomic) IBOutlet UIButton *btn_sc;
@property (weak, nonatomic) IBOutlet UIButton *btn_comments;
@end

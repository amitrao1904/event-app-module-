//
//  DRVInviteCrewUserVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 09/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVInviteCrewUserVC.h"
#import "CustomSendInviteCell.h"
@interface DRVInviteCrewUserVC ()
{
    CustomSendInviteCell *prototypeCell;
    
}

@end

@implementation DRVInviteCrewUserVC
@synthesize tbl_new,txt_search;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIColor *color = [UIColor lightGrayColor];
    txt_search.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Search.." attributes:@{NSForegroundColorAttributeName: color}];
    
    
    
    
    
    array_list1=[[NSMutableArray alloc]init];
    
    [array_list1 addObject:@"1"];
    [array_list1 addObject:@"2"];
    [array_list1 addObject:@"2"];
    [array_list1 addObject:@"1"];
    [array_list1 addObject:@"1"];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)sendinvite_Action:(id)sender {
    
//    DRVEventDetaIlVC2 *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventDetaIlVC2"];
//    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)skip_Action:(id)sender {
    
    CrewTimelineVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewTimelineVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list1 count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomSendInviteCell *)[tbl_new dequeueReusableCellWithIdentifier:NSStringFromClass([CustomSendInviteCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[CustomSendInviteCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([CustomSendInviteCell class])];
    }
    
    
    
    
    NSString *str=[array_list1 objectAtIndex:indexPath.row];
    
    
    if ([str isEqualToString:@"1"]) {
        
        prototypeCell.btn_invite.layer.cornerRadius=0;
        prototypeCell.btn_invite.layer.masksToBounds=YES;
        prototypeCell.btn_invite.layer.borderWidth = 1;
        prototypeCell.btn_invite.layer.borderColor = [UIColor whiteColor].CGColor;
        
        [prototypeCell.btn_invite setTitle:@"Invite" forState:UIControlStateNormal];
        prototypeCell.btn_invite.layer.backgroundColor = [UIColor clearColor].CGColor;
        
        [prototypeCell.btn_invite setTitle:@"Invite" forState:UIControlStateNormal];
        
    }
    else
    {
        
        prototypeCell.btn_invite.layer.backgroundColor = [UIColor whiteColor].CGColor;
        [prototypeCell.btn_invite setTitle:@"Selected" forState:UIControlStateNormal];
        [prototypeCell.btn_invite setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    }
    
    
    return prototypeCell;
}






#pragma mark - Memory CleanUP

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

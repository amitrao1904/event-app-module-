//
//  DRVCrewBlockedUserVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 09/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCrewBlockedUserVC.h"
#import "DRVCustomCrewBlockedCell.h"
@interface DRVCrewBlockedUserVC ()
{
    DRVCustomCrewBlockedCell *prototypeCell;
    
}
@end

@implementation DRVCrewBlockedUserVC
@synthesize tbl_new;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods




#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)sendinvite_Action:(id)sender {
    
    //    DRVEventDetaIlVC2 *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventDetaIlVC2"];
    //    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)skip_Action:(id)sender {
    
    CrewTimelineVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewTimelineVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (DRVCustomCrewBlockedCell *)[tbl_new dequeueReusableCellWithIdentifier:NSStringFromClass([DRVCustomCrewBlockedCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[DRVCustomCrewBlockedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([DRVCustomCrewBlockedCell class])];
    }
    
    prototypeCell.btn_block.layer.cornerRadius=0;
    prototypeCell.btn_block.layer.masksToBounds=YES;
    prototypeCell.btn_block.layer.borderWidth = 1;
    prototypeCell.btn_block.layer.borderColor = [UIColor whiteColor].CGColor;
    
    

    
    return prototypeCell;
}




#pragma mark - Memory CleanUP

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

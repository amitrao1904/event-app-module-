//
//  DRVCrewBlockedUserVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 09/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVCrewBlockedUserVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    
    NSMutableArray *array_list1;
    
}
@property (strong, nonatomic) IBOutlet UITableView *tbl_new;

@end

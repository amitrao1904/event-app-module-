//
//  SearchFollowVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchFollowVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    
}
@property (strong, nonatomic) IBOutlet UITableView *tbl_new;

@end

//
//  NotificationAdminVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 05/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "NotificationAdminVC.h"

@interface NotificationAdminVC ()

@end

@implementation NotificationAdminVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method
#pragma mark - API Methods
#pragma mark - Action Method

-(IBAction)menu_Action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)chat_Action:(id)sender
{
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
    
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

- (IBAction)reported_Action:(id)sender {
    CrewReportsPostVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewReportsPostVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
    
}
- (IBAction)member_Action:(id)sender {
    
    CrewMemberRqstVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewMemberRqstVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)invite_Action:(id)sender
{
    
    DRVInviteCrewUserVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInviteCrewUserVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)blocked_Action:(id)sender
{
    DRVCrewBlockedUserVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVCrewBlockedUserVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)edit_Action:(id)sender {
    
    EditCrewSettingVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditCrewSettingVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)share_Action:(id)sender {
}
- (IBAction)notificationsetting_Action:(id)sender {
    
    CrewPushNoticationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewPushNoticationVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)delete_Action:(id)sender {
}
- (IBAction)leave_Action:(id)sender {
}





#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

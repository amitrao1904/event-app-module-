//
//  SearchCrewBatteryVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchCrewBatteryVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    NSMutableArray *array_list1;
    NSMutableArray *array_list2;
    NSMutableArray *array_list3;
    NSMutableArray *array_list4;
    
}
@property (strong, nonatomic) IBOutlet UITableView *tbl_new;

@end

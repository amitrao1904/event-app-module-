//
//  CustomMemberCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomMemberCell.h"

@implementation CustomMemberCell
@synthesize label1,label2,imageinvite,btn_arrow;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

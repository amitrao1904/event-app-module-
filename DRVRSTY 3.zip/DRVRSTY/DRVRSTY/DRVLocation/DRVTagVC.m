//
//  DRVTagVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 11/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVTagVC.h"
#import "DRVCustomLocationSearchCell.h"
@interface DRVTagVC ()
{
    DRVCustomLocationSearchCell *prototypeCell;
    
}
@end

@implementation DRVTagVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method


#pragma mark - API Methods



#pragma mark - Action Method

#pragma mark - Action Method
-(IBAction)back_Action:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)cross_Action:(id)sender
{
    
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (DRVCustomLocationSearchCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([DRVCustomLocationSearchCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[DRVCustomLocationSearchCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([DRVCustomLocationSearchCell class])];
    }
    
    
    return prototypeCell;
}


#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

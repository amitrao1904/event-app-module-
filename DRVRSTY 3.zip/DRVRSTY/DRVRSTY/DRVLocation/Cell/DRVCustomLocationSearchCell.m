//
//  DRVCustomLocationSearchCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCustomLocationSearchCell.h"

@implementation DRVCustomLocationSearchCell
@synthesize label1,label2;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

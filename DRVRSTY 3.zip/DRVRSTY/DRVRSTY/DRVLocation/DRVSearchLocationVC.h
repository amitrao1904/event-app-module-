//
//  DRVSearchLocationVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVSearchLocationVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    NSMutableArray *array_list;
    NSMutableArray *array_list1;
    NSMutableArray *array_list2;
    NSUserDefaults *def;
    
}


@property (strong, nonatomic) IBOutlet UITableView *tblNew;

@end

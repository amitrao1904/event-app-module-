//
//  DRVSearchLocationVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVSearchLocationVC.h"
#import "DRVCustomLocationSearchCell.h"
@interface DRVSearchLocationVC ()
{
    DRVCustomLocationSearchCell *prototypeCell;
    
}
@end

@implementation DRVSearchLocationVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    array_list=[[NSMutableArray alloc]init];
    array_list1=[[NSMutableArray alloc]init];
    
    [array_list addObject:@"Name of Place"];
    [array_list addObject:@"Eastern Creek Raceway"];
    [array_list addObject:@"Name of Place"];
    [array_list addObject:@"Eastern Creek Raceway"];
    [array_list addObject:@"Name of Place"];
    [array_list addObject:@"Name of Place"];
    
    [array_list1 addObject:@"Address"];
    [array_list1 addObject:@"123 Peter Brock Drive,Eastern creek"];
    [array_list1 addObject:@"Address"];
    [array_list1 addObject:@"123 Peter Brock Drive,Eastern creek"];
    [array_list1 addObject:@"Address"];
    [array_list1 addObject:@"Address"];
    
    
    

    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back_Action:(id)sender
{

    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)cross_Action:(id)sender
{

}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (DRVCustomLocationSearchCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([DRVCustomLocationSearchCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[DRVCustomLocationSearchCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([DRVCustomLocationSearchCell class])];
    }
    prototypeCell.label1.text=[array_list objectAtIndex:indexPath.row];
    
    
    prototypeCell.label2.text=[array_list1 objectAtIndex:indexPath.row];
    
    
    return prototypeCell;
}

#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

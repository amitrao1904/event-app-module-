//
//  image.h
//
//  Created by admin on 27/01/15.
//  Copyright (c) 2015 admin. All rights reserved.


#define background_image @"background-7.jpg"

#define BACKGROUNDCOLOR [UIColor colorWithRed:0 green:0 blue:0 alpha:1]

#define HEADERBACKGROUND [UIColor colorWithRed:0 green:0 blue:0 alpha:1]

#define FOOTERBACKGROUND [UIColor colorWithRed:0 green:0 blue:0 alpha:1]

#define TABLEVIEWBACKGROUND [UIColor colorWithRed:0 green:0 blue:0 alpha:1]

#define TABLEVIEWCELLBACKGROUND [UIColor colorWithRed:0 green:0 blue:0 alpha:1]

#define POPUPBACKGROUND [UIColor colorWithRed:0 green:0 blue:0 alpha:1]

#define UNDERLINEBACKGROUND [UIColor colorWithRed:0 green:0 blue:0 alpha:1]





//service view controller
#define Requestappointement [UIColor colorWithRed:0.251 green:0.349 blue:0.384 alpha:1]
#define Myrequest [UIColor colorWithRed:0.102 green:0.267 blue:0.325 alpha:1]
#define Feedback [UIColor colorWithRed:0.102 green:0.267 blue:0.325 alpha:1]


//Login Page

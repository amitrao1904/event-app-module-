//
//  MyMapVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyMapVC : UIViewController


@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;
@property (strong, nonatomic) IBOutlet UIButton *btnmotoron;
@property (strong, nonatomic) IBOutlet UIButton *btnmotoroff;

@property (strong, nonatomic) IBOutlet UIButton *btntollon;
@property (strong, nonatomic) IBOutlet UIButton *btntolloff;
@end

//
//  DRVPostVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 11/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVPostVC : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btn_post;

@end

//
//  DRVPostVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 11/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVPostVC.h"

@interface DRVPostVC ()

@end

@implementation DRVPostVC
@synthesize btn_post;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    btn_post.layer.borderWidth=1;
    btn_post.layer.borderColor=[UIColor colorWithRed:0/255.0 green:122/255.0 blue:255/255.0 alpha:1].CGColor;
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method


#pragma mark - API Methods



#pragma mark - Action Method
- (IBAction)cross_Action:(id)sender {
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController popViewControllerAnimated:NO];

}
- (IBAction)post_Action:(id)sender
{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController popViewControllerAnimated:NO];
}
- (IBAction)tag_Action:(id)sender
{
   
    DRVTagVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVTagVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)location_Action:(id)sender {
    
    DRVSearchLocationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSearchLocationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}



#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

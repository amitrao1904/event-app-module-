//
//  AppDelegate.h
//  KrewCal
//
//  Created by Deepak Pandey on 5/26/15.
//  Copyright (c) 2015 Neuron Solutions Inc. All rights reserved.
//

#import "ServiceManager.h"
@implementation ServiceManager

+ (instancetype)sharedClient
{
    static ServiceManager *_sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedClient = [[ServiceManager alloc] initWithBaseURL:[NSURL URLWithString:BASE_URL]];
        _sharedClient.securityPolicy    = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        _sharedClient.requestSerializer = [AFJSONRequestSerializer serializer];
        
    });
    
    return _sharedClient;
}

#pragma mark - Custom Methods
/**
 *  Handle web service resonse erorrs
 */

- (void)handleResponseError:(NSError *)error onView:(UIView *)view forTask:(TaskType)task{
    //**  Hide HUD
    [appDelegate() hideHUDFromView:view];
    
    DLog(@"Server Failure response: %@", error);

}



/**
 *  Perfrom api call using NSOperation
 */
- (void)apiCallUsingOperationManagerHTTPMethod:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)task currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock
{
    //**  Show HUD
    [appDelegate() showHUDWithTxt:nil onView:view];
    
    //**  Set Accecss token in API call if required
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer              = [AFJSONRequestSerializer serializer];
    manager.requestSerializer.HTTPMethodsEncodingParametersInURI = [NSSet setWithArray:@[@"POST", @"GET", @"HEAD"]];
    
    //** Get Request
    if (method == GET)
    {
        
        [manager GET:urlString parameters:postParameters success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             DLog(@"\n GET API URL:%@\n Request Parameter:%@, Response:%@",urlString,postParameters, responseObject);

             BOOL isSuccess = [[responseObject valueForKey:RESPONSE_SUCCESS] boolValue];
             
             completionBlock(responseObject, operation.error, task, isSuccess);
             
             //**  Hide HUD
             [appDelegate() hideHUDFromView:view];
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             [self handleResponseError:error onView:view forTask:task];
             
         }];
        
    }
    else//** POST Request
        if (method == POST) {
            
           
            
            AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:urlString]];
            manager.responseSerializer = [AFJSONResponseSerializer serializer];
            manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
            
            
            AFHTTPRequestOperation *apiRequest = [manager POST:@"" parameters:postParameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData)
                                                  { }
                                                       success:^(AFHTTPRequestOperation *operation, id responseObject)
                                                  {
                                                      NSLog(@"response ---%@",responseObject);
                                                      
                                                      BOOL isSuccess = [[responseObject valueForKey:RESPONSE_STATUS] boolValue];
                                                      
                                                      //**  Hide HUD
                                                      [appDelegate() hideHUDFromView:view];
                                                      
                                                      completionBlock(responseObject, nil, task, isSuccess);
                                                      
                                                  } failure:^(AFHTTPRequestOperation *operation, NSError *error)
                                                  {
                                                      NSLog(@"response ---%@",error);
                                                      //**  Hide HUD
                                                      [self handleResponseError:error onView:view forTask:task];
                                                  }];
            
            [apiRequest start];
        }
    
}

- (void)apiCallUsingOperationManagerHTTPMethod1:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)task currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock
{
    //**  Show HUD
    // [appDelegate() showHUDWithTxt:nil onView:view];
    
    //**  Set Accecss token in API call if required
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer              = [AFJSONRequestSerializer serializer];
    manager.requestSerializer.HTTPMethodsEncodingParametersInURI = [NSSet setWithArray:@[@"POST", @"GET", @"HEAD"]];
    
    //** Get Request
    if (method == GET) {
        
        [manager GET:urlString parameters:postParameters success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             DLog(@"\n GET API URL:%@\n Request Parameter:%@, Response:%@",urlString,postParameters, responseObject);
             
             BOOL isSuccess = [[responseObject valueForKey:RESPONSE_SUCCESS] boolValue];
             
             completionBlock(responseObject, operation.error, task, isSuccess);
             
             //**  Hide HUD
             [appDelegate() hideHUDFromView:view];
             
         } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
             [self handleResponseError:error onView:view forTask:task];
             
         }];
        
    }
    else//** POST Request
        if (method == POST) {
            
            
            
            AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:urlString]];
            manager.responseSerializer = [AFJSONResponseSerializer serializer];
            manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
            
            
            AFHTTPRequestOperation *apiRequest = [manager POST:@"" parameters:postParameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData)
                                                  { }
                                                       success:^(AFHTTPRequestOperation *operation, id responseObject)
                                                  {
                                                      NSLog(@"response ---%@",responseObject);
                                                      
                                                      BOOL isSuccess = [[responseObject valueForKey:RESPONSE_STATUS] boolValue];
                                                      
                                                      //**  Hide HUD
                                                      //  [appDelegate() hideHUDFromView:view];
                                                      
                                                      completionBlock(responseObject, nil, task, isSuccess);
                                                      
                                                  } failure:^(AFHTTPRequestOperation *operation, NSError *error)
                                                  {
                                                      NSLog(@"response ---%@",error);
                                                      //**  Hide HUD
                                                      [self handleResponseError:error onView:view forTask:task];
                                                  }];
            
            [apiRequest start];
        }
    
}

/**
 *  Perfrom api call using MultipartForm Data
 */

- (void)multipartAPICallUsingDataTaskHTTPMethod:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)apiTask currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock
{
    //**  Show HUD
    [appDelegate() showHUDWithTxt:nil onView:view];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
  
    [manager POST:urlString parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {

        [postParameters enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
            NSLog(@"key= %@", key);
            
            if ([key isEqualToString:@"TmpUsers[avtar]"] || [key isEqualToString:@"User[avtar]"])
            {
                 [formData appendPartWithFileData:object name:key fileName:[NSString stringWithFormat:@"%@.jpg", key] mimeType:@"image/jpeg"];
            } else
            {
                [formData appendPartWithFormData:[object dataUsingEncoding:NSUTF8StringEncoding]
                                            name:key];

            }
            
        }];
    }
          success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         DLog(@"\n POST API URL:%@\n Request Parameter:%@, Response:%@",operation.response.URL, postParameters, responseObject);
         
         BOOL isSuccess = [[responseObject valueForKey:RESPONSE_SUCCESS] boolValue];
         
         completionBlock(responseObject, nil, apiTask, isSuccess);
         
         //** Hide HUD
         [appDelegate() hideHUDFromView:view];
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [self handleResponseError:error onView:view forTask:apiTask];
     }];
    
}
- (void)multipartAPICallUsingDataTaskHTTPMethod1:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)apiTask currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock
{
    //**  Show HUD
    [appDelegate() showHUDWithTxt:nil onView:view];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    
    [manager POST:urlString parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        [postParameters enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
            NSLog(@"key= %@", key);
            
            if ([key isEqualToString:@"cheque_copy"]) {
                [formData appendPartWithFileData:object name:key fileName:[NSString stringWithFormat:@"%@.jpg", key] mimeType:@"image/jpeg"];
            } else {
                [formData appendPartWithFormData:[object dataUsingEncoding:NSUTF8StringEncoding]
                                            name:key];
                
            }
            
        }];
    }
          success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         DLog(@"\n POST API URL:%@\n Request Parameter:%@, Response:%@",operation.response.URL, postParameters, responseObject);
         
         BOOL isSuccess = [[responseObject valueForKey:RESPONSE_SUCCESS] boolValue];
         
         completionBlock(responseObject, nil, apiTask, isSuccess);
         
         //** Hide HUD
         [appDelegate() hideHUDFromView:view];
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [self handleResponseError:error onView:view forTask:apiTask];
     }];
    
}
- (void)multipartAPICallUsingDataTaskHTTPMethod2:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)apiTask currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock
{
    //**  Show HUD
    [appDelegate() showHUDWithTxt:nil onView:view];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    
    [manager POST:urlString parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        [postParameters enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
            NSLog(@"key= %@", key);
            
            if ([key isEqualToString:@"cheque_copy"] || [key isEqualToString:@"cancel_cheque"]) {
                [formData appendPartWithFileData:object name:key fileName:[NSString stringWithFormat:@"%@.jpg", key] mimeType:@"image/jpeg"];
            } else {
                [formData appendPartWithFormData:[object dataUsingEncoding:NSUTF8StringEncoding]
                                            name:key];
                
            }
            
        }];
    }
          success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         DLog(@"\n POST API URL:%@\n Request Parameter:%@, Response:%@",operation.response.URL, postParameters, responseObject);
         
         BOOL isSuccess = [[responseObject valueForKey:RESPONSE_SUCCESS] boolValue];
         
         completionBlock(responseObject, nil, apiTask, isSuccess);
         
         //** Hide HUD
         [appDelegate() hideHUDFromView:view];
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [self handleResponseError:error onView:view forTask:apiTask];
     }];
    
}

@end

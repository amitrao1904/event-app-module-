//
//  AppDelegate.h
//  KrewCal
//
//  Created by Deepak Pandey on 5/26/15.
//  Copyright (c) 2015 Neuron Solutions Inc. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "Constant.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import "AFNetworkActivityIndicatorManager.h"

@interface ServiceManager : AFHTTPSessionManager

+ (instancetype)sharedClient;

/**
 *  Perfrom api call using NSOperation. This method use only if you face any problem in |apiCallUsingDataTaskHTTPMethod| and |apiCallUsingOperationManagerHTTPMethod|
 */
- (void)apiCallUsingOperationManagerHTTPMethod:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)task currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock;
/**
 * MultipartFormData API Call
 */
- (void)multipartAPICallUsingDataTaskHTTPMethod:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)apiTask currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock;

- (void)apiCallUsingOperationManagerHTTPMethod1:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)task currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock;

- (void)multipartAPICallUsingDataTaskHTTPMethod1:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)apiTask currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock;

- (void)multipartAPICallUsingDataTaskHTTPMethod2:(HTTPMethod)method url:(NSString*)urlString andParameters:(NSDictionary *)postParameters forTask:(TaskType)apiTask currentView:(UIView *)view accessToken:(BOOL)isAccessToken completionHandler:(void (^)(id response, NSError *error, TaskType task, BOOL success))completionBlock;


@end

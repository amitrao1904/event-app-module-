//
//  MyNotificationVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 04/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "MyNotificationVC.h"
#import "MyNotificationCell.h"
@interface MyNotificationVC ()
{
    MyNotificationCell *prototypeCell;
    
}
@end

@implementation MyNotificationVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    array_list=[[NSMutableArray alloc]init];
    array_list1=[[NSMutableArray alloc]init];
    
    [array_list1 addObject:@"Andrew"];
    [array_list1 addObject:@"Alexies"];
    [array_list1 addObject:@"Alexies"];
    [array_list1 addObject:@"Step"];
    
    
    [array_list addObject:@"Andrew started following you"];
    [array_list addObject:@"Alexies gave you XP for your photo"];
    [array_list addObject:@"Alexies started following you"];
    [array_list addObject:@"Step gave you XP for your performance specs."];
    
    
    [array_list addObject:@"Step gave you XP for your style specs"];
    [array_list addObject:@"Andrew commented: Nice!"];
    [array_list addObject:@"Andrew invited you to his event Friday Night Cruise"];
    [array_list addObject:@"Your Facebook friend Alexix Adao is on DRVRSTY."];
    
    
    [array_list addObject:@"Andrew mentioned you in a comment."];
    [array_list addObject:@"Red Crew has invited you to join their crew."];
    [array_list addObject:@"Red Crew has accepted your request to join their crew."];
    [array_list addObject:@"Today is Steph's birthday!"];
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
- (IBAction)menu_Action:(id)sender
{
    
    DRVSetting1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting1VC"];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController pushViewController:addinvController animated:NO];
    
    
}
- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
   
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (MyNotificationCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([MyNotificationCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[MyNotificationCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([MyNotificationCell class])];
    }
    prototypeCell.label1.text=[array_list objectAtIndex:indexPath.row];
  //  NSString *str=[array_list objectAtIndex:indexPath.row];
    
    prototypeCell.label1.text=[array_list objectAtIndex:indexPath.row];
   // prototypeCell.label11.text=[array_list1 objectAtIndex:indexPath.row];
    
    if (indexPath.row==0) {
        
        prototypeCell.btn_follow.hidden=NO;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=YES;
        
        prototypeCell.image1.image=[UIImage imageNamed:@"user-icon"];
        
        

        
        
    }
    if (indexPath.row==1) {
        
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=NO;
        prototypeCell.image_specs.hidden=YES;
        
        prototypeCell.random_image1.image=[UIImage imageNamed:@"client.jpeg"];
        
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        
    }
    if (indexPath.row==2) {
        prototypeCell.image1.image=[UIImage imageNamed:@"user-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=NO;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=YES;
        
        prototypeCell.btn_unfollow.layer.borderWidth=1;
        prototypeCell.btn_unfollow.layer.borderColor=[UIColor whiteColor].CGColor;
        
        
        [prototypeCell.btn_unfollow setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        
        
    }
    if (indexPath.row==3) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=NO;
        
        prototypeCell.image_specs.image=[UIImage imageNamed:@"speed-meter-none-icon"];
        
    }
    if (indexPath.row==4) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=NO;
        
        prototypeCell.image_specs.image=[UIImage imageNamed:@"timeline-none-icon"];
        
    }
    if (indexPath.row==5) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=NO;
        
        prototypeCell.image_specs.image=[UIImage imageNamed:@"sound-none-icon"];
        
    }
    if (indexPath.row==6) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=NO;
        
        prototypeCell.image_specs.image=[UIImage imageNamed:@"event-none-icno"];
        
    }
    if (indexPath.row==7) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=NO;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=YES;
        
       
        prototypeCell.image_specs.image=[UIImage imageNamed:@"event-none-icno"];
        
    }
    if (indexPath.row==8) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=NO;
        prototypeCell.image_specs.hidden=YES;
        
        prototypeCell.random_image1.image=[UIImage imageNamed:@"client.jpeg"];
        
    }
    if (indexPath.row==9) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=NO;
        prototypeCell.image_specs.hidden=YES;
        
        prototypeCell.random_image1.image=[UIImage imageNamed:@"app-logo"];
        
    }
    if (indexPath.row==10) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=NO;
        prototypeCell.image_specs.hidden=YES;
        
        prototypeCell.random_image1.image=[UIImage imageNamed:@"app-logo"];
        
    }
    if (indexPath.row==11) {
        prototypeCell.image1.image=[UIImage imageNamed:@"notification-icon"];
        prototypeCell.btn_follow.hidden=YES;
        prototypeCell.btn_unfollow.hidden=YES;
        prototypeCell.random_image1.hidden=YES;
        prototypeCell.image_specs.hidden=YES;
        
        
        
    }
    
    
    
    
    
    return prototypeCell;
}

#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

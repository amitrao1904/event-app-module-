//
//  MyNotificationCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 04/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "MyNotificationCell.h"

@implementation MyNotificationCell
@synthesize img_profile,label1,label11,label2,btn_follow,btn_unfollow,image1,random_image1,image_specs;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

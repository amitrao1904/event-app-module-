//
//  MyNotificationCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 04/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNotificationCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *img_profile;
@property (strong, nonatomic) IBOutlet UILabel *label1;
@property (strong, nonatomic) IBOutlet UILabel *label11;
@property (strong, nonatomic) IBOutlet UILabel *label2;
@property (strong, nonatomic) IBOutlet UIImageView *image1;
@property (strong, nonatomic) IBOutlet UIButton *btn_follow;
@property (strong, nonatomic) IBOutlet UIButton *btn_unfollow;

@property (strong, nonatomic) IBOutlet UIImageView *random_image1;

@property (strong, nonatomic) IBOutlet UIImageView *image_specs;

@end

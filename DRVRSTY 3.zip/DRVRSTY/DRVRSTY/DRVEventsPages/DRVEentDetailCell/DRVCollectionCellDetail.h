//
//  DRVCollectionCellDetail.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVCollectionCellDetail : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *img_profile;
@property (weak, nonatomic) IBOutlet UIButton *btn_camera;
@end

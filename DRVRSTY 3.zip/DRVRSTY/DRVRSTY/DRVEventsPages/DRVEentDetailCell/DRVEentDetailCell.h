//
//  DRVEentDetailCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVEentDetailCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (weak, nonatomic) IBOutlet UIButton *btn_edit;
@property (weak, nonatomic) IBOutlet UIButton *btn_invite;
@property (weak, nonatomic) IBOutlet UIButton *btn_arrow;
@property (weak, nonatomic) IBOutlet UIButton *btn_camera;
@end

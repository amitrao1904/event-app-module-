//
//  DRVEventDetailCell1.m
//  DRVRSTY
//
//  Created by Macbook pro on 09/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVEventDetailCell1.h"

@implementation DRVEventDetailCell1
@synthesize label1,label2,label3,imageinvite,btn_XP,btn_comment,btn_camera;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

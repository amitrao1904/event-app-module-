//
//  DRVCollectionCellDetail.m
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCollectionCellDetail.h"

@implementation DRVCollectionCellDetail
@synthesize img_profile,btn_camera;
@end

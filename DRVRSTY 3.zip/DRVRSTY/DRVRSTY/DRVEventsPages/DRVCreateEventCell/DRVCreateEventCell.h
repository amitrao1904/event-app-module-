//
//  DRVCreateEventCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 03/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVCreateEventCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btn_photo;
@property (strong, nonatomic) IBOutlet UILabel *lbl_optional;

@property (strong, nonatomic) IBOutlet UITextField *txt_name;

@property (strong, nonatomic) IBOutlet UIButton *btn_date;
@property (strong, nonatomic) IBOutlet UIButton *btn_starttime;
@property (strong, nonatomic) IBOutlet UIButton *btn_endtime;

@property (strong, nonatomic) IBOutlet UIButton *btn_meet;
@property (strong, nonatomic) IBOutlet UIButton *btn_cruise;
@property (strong, nonatomic) IBOutlet UIButton *btn_public;
@property (strong, nonatomic) IBOutlet UIButton *btn_private;

@property (strong, nonatomic) IBOutlet UITextField *txt_description;

@property (strong, nonatomic) IBOutlet UIButton *btn_location;
@property (strong, nonatomic) IBOutlet UIButton *btn_done;

@property (strong, nonatomic) IBOutlet UIButton *btn_createevent;
@property (strong, nonatomic) IBOutlet UIButton *btn_invite;

@end

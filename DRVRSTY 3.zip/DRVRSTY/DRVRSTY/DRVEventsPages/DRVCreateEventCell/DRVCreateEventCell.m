//
//  DRVCreateEventCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 03/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCreateEventCell.h"

@implementation DRVCreateEventCell
@synthesize txt_name,txt_description,btn_date,btn_done,btn_meet,btn_photo,btn_cruise,btn_public,btn_endtime,btn_private,btn_location,btn_starttime,lbl_optional,btn_createevent,btn_invite;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

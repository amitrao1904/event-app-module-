//
//  DRVEventVC1.m
//  DRVRSTY
//
//  Created by Macbook pro on 02/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVEventVC1.h"
#import "DRVEventFirstCell.h"
@interface DRVEventVC1 ()
{
    DRVEventFirstCell *prototypeCell;
    
}
@end

@implementation DRVEventVC1
@synthesize tblNew,view1,view2,view3,btn_meet,btn_cruise;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    btn_meet.layer.cornerRadius=0;
    btn_meet.layer.masksToBounds=YES;
    btn_meet.layer.borderWidth = 1;
    btn_meet.layer.borderColor = [UIColor whiteColor].CGColor;
    
    btn_cruise.layer.cornerRadius=0;
    btn_cruise.layer.masksToBounds=YES;
    btn_cruise.layer.borderWidth = 1;
    btn_cruise.layer.borderColor = [UIColor whiteColor].CGColor;
    
    def=[NSUserDefaults standardUserDefaults];
    
    array_list=[[NSMutableArray alloc]init];
    array_list1=[[NSMutableArray alloc]init];
    array_list2=[[NSMutableArray alloc]init];
    
     [array_list addObject:@"Friday Night Cruise"];
     [array_list addObject:@"Meetup"];
     [array_list addObject:@"Weekend Cruise"];
     [array_list addObject:@"Birthday Meetup"];
     [array_list addObject:@"Drag Race"];
    
    [array_list1 addObject:@"Today at 8:00PM"];
    [array_list1 addObject:@"10 March at 5:30PM"];
    [array_list1 addObject:@"17 March at 3:00PM"];
    [array_list1 addObject:@"14 June at 8:00PM"];
    [array_list1 addObject:@"24 July at 11:00PM"];
    
    
    [array_list2 addObject:@"1"];
    [array_list2 addObject:@"2"];
    [array_list2 addObject:@"1"];
    [array_list2 addObject:@"2"];
    [array_list2 addObject:@"1"];
    
    
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back_Action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)refine_Action:(id)sender
{
    view1.hidden=NO;
    view3.hidden=NO;

}
-(IBAction)create_Action:(id)sender
{

    DRVCreateEventNewVC2 *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVCreateEventNewVC2"];
    [self.navigationController pushViewController:registercontroller animated:true];
    
}
-(IBAction)chat_Action:(id)sender
{

    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}


-(IBAction)view1_hidden:(id)sender
{
     view1.hidden=YES;
     view2.hidden=YES;
    
     view3.hidden=YES;
}
-(IBAction)going_Action:(id)sender
{
}
-(IBAction)maybe_Action:(id)sender
{
}
-(IBAction)cantgo_Action:(id)sender
{
}


-(IBAction)meet_Action:(id)sender
{

    btn_meet.backgroundColor=[UIColor whiteColor];
    [btn_meet setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_cruise.backgroundColor=[UIColor clearColor];
    [btn_cruise setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}
-(IBAction)cruise_Action:(id)sender
{

    btn_meet.backgroundColor=[UIColor clearColor];
    [btn_meet setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_cruise.backgroundColor=[UIColor whiteColor];
    [btn_cruise setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}
-(IBAction)location_Action:(id)sender
{
    DRVSearchLocationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSearchLocationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

-(IBAction)search_Action:(id)sender
{

    view1.hidden=YES;
    view3.hidden=YES;
}

- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search1_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (DRVEventFirstCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([DRVEventFirstCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[DRVEventFirstCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([DRVEventFirstCell class])];
    }
    
    NSString *str=[array_list2 objectAtIndex:indexPath.row];
    
    if ([str isEqualToString:@"1"])
    {
        prototypeCell.image1.image=[UIImage imageNamed:@"going-icon"];
    }
    else
    {
    
        prototypeCell.image1.image=[UIImage imageNamed:@"maybe-icon"];
    
    }
    
    prototypeCell.btn_arrow.tag = indexPath.row;
    [prototypeCell.btn_arrow addTarget:self action:@selector(yourarrowButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    prototypeCell.label1.text=[array_list objectAtIndex:indexPath.row];
    
    prototypeCell.label2.text=[array_list1 objectAtIndex:indexPath.row];
    
    
    
    
    return prototypeCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DRVEventDetaIlVC *forgotcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventDetaIlVC"];
    [self.navigationController pushViewController:forgotcontroller animated:true];

}
-(void)yourarrowButtonClicked:(UIButton*)btn
{
    
    NSString *str1=[array_list2 objectAtIndex:btn.tag];
    
    if ([str1 isEqualToString:@"1"])
    {
        
    }
    else
    {

        view1.hidden=NO;
        view2.hidden=NO;
    }
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"CUSTOM VIEW");
}

#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  DRVEventVC1.h
//  DRVRSTY
//
//  Created by Macbook pro on 02/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVEventVC1 : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    NSMutableArray *array_list;
    NSMutableArray *array_list1;
    NSMutableArray *array_list2;
    NSUserDefaults *def;
    
}
@property (weak, nonatomic) IBOutlet UITextField *txt_search;

@property (strong, nonatomic) IBOutlet UITableView *tblNew;

@property (strong, nonatomic) IBOutlet UIView *view1;

@property (strong, nonatomic) IBOutlet UIView *view2;

@property (strong, nonatomic) IBOutlet UIView *view3;

@property (strong, nonatomic) IBOutlet UIButton *btn_meet;
@property (strong, nonatomic) IBOutlet UIButton *btn_cruise;
@property (strong, nonatomic) IBOutlet UITextField *txt_location;


@end

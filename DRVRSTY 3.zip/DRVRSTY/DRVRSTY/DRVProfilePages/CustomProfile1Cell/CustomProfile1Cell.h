//
//  CustomProfile1Cell.h
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomProfile1Cell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btn_8SC;
@property (strong, nonatomic) IBOutlet UIButton *btn_comment;
@end

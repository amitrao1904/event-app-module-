//
//  ProfilePhotos18VC.m
//  DRVRSTY
//
//  Created by Macbook pro on 02/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "ProfilePhotos18VC.h"

@interface ProfilePhotos18VC ()

@end

@implementation ProfilePhotos18VC
@synthesize btn_edit,collectionView;
- (void)viewDidLoad {
    [super viewDidLoad];
    btn_edit.layer.cornerRadius=1;
    btn_edit.layer.borderWidth=1;
    btn_edit.layer.borderColor=[UIColor whiteColor].CGColor;
    // Do any additional setup after loading the view.
}


- (IBAction)menu_Action:(id)sender {
    
    DRVSetting1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting1VC"];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)yourcrew_Action:(id)sender {
    
    
    DRVYourCrewsVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVYourCrewsVC"];
    [self.navigationController pushViewController:login animated:true];
}
- (IBAction)edit_Action:(id)sender {
    
    
    ProfileEditProfileVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileEditProfileVC"];
    [self.navigationController pushViewController:login animated:true];
}

- (IBAction)specs_Action:(id)sender
{
    ProfileVC7 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileVC7"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)timeline_Action:(id)sender
{
    
    
    Profile1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"Profile1VC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
    
}
#pragma mark - Collectionview Delegate Method
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 12;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"Cellcategory";
    
    UICollectionViewCell *cell = [cv dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    // UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    
    
    
    
    
    return cell;
}
#pragma mark - UICollectionView Delegate
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  ProfileVC7.h
//  DRVRSTY
//
//  Created by Macbook pro on 13/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileVC7 : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate, UIActionSheetDelegate,UIScrollViewDelegate,UIDocumentInteractionControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{

    BOOL imageflag;
    UIImage *finalImage;
    NSData *dataImage;
    IBOutlet UIButton *postImage;
    NSData *imageData;
    NSData *eventImageData1;

}
@property(weak,nonatomic) IBOutlet UIButton *btn_edit;
@property (weak, nonatomic) IBOutlet UILabel *lbl_performance;
@property (weak, nonatomic) IBOutlet UIButton *btn_tyre;
@property (weak, nonatomic) IBOutlet UIButton *btn_sound;
@property (weak, nonatomic) IBOutlet UIButton *btn_meter;
@property (strong, nonatomic) IBOutlet UIImageView *imageview1;



@end

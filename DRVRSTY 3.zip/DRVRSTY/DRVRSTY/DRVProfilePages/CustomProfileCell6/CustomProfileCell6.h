//
//  CustomProfileCell6.h
//  DRVRSTY
//
//  Created by Macbook pro on 13/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomProfileCell6 : UITableViewCell

@end

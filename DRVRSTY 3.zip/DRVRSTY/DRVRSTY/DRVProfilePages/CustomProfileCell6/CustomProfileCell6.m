//
//  CustomProfileCell6.m
//  DRVRSTY
//
//  Created by Macbook pro on 13/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomProfileCell6.h"

@implementation CustomProfileCell6

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

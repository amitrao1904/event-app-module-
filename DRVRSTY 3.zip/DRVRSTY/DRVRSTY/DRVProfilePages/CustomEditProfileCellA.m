//
//  CustomEditProfileCellA.m
//  DRVRSTY
//
//  Created by Macbook pro on 02/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomEditProfileCellA.h"

@implementation CustomEditProfileCellA
@synthesize txt_make,txt_year,txt_email,txt_model,txt_phone,txt_location,txt_username,btn_applychanges,btn_changeprofile;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

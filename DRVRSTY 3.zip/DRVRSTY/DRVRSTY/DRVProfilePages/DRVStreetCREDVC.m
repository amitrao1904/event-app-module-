//
//  DRVStreetCREDVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 15/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVStreetCREDVC.h"
#import "CustomProfileNetworkCell.h"
@interface DRVStreetCREDVC ()
{
    CustomProfileNetworkCell *prototypeCell;
    
}
@end

@implementation DRVStreetCREDVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    array_list=[[NSMutableArray alloc]init];
    
    [array_list addObject:@"2"];
    [array_list addObject:@"1"];
    [array_list addObject:@"2"];
    [array_list addObject:@"2"];
    [array_list addObject:@"1"];
    [array_list addObject:@"2"];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)menu_Action:(id)sender
{
//    DRVSetting1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting1VC"];
//    
//    CATransition *transition = [CATransition animation];
//    transition.duration = 0.45;
//    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
//    transition.type = kCATransitionPush;
//    transition.subtype = kCATransitionFromLeft;
//    [self.navigationController.view.layer addAnimation:transition forKey:nil];
//    
//    //self.navigationController.navigationBarHidden = NO;
//    [self.navigationController pushViewController:addinvController animated:NO];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
    
}
- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomProfileNetworkCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([CustomProfileNetworkCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[CustomProfileNetworkCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([CustomProfileNetworkCell class])];
    }
    
    NSString *str1=[array_list objectAtIndex:indexPath.row];
    
    if ([str1 isEqualToString:@"1"])
    {
        // prototypeCell.btn_follow.layer.borderWidth=1;
        prototypeCell.btn_follow.layer.backgroundColor=[UIColor whiteColor].CGColor;
        [prototypeCell.btn_follow setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [prototypeCell.btn_follow setTitle:@"Follow" forState:UIControlStateNormal];
    }
    else
    {
        
        prototypeCell.btn_follow.layer.borderWidth=1;
        prototypeCell.btn_follow.layer.borderColor=[UIColor whiteColor].CGColor;
        prototypeCell.btn_follow.layer.backgroundColor=[UIColor clearColor].CGColor;
        [prototypeCell.btn_follow setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        [prototypeCell.btn_follow setTitle:@"Unfollow" forState:UIControlStateNormal];
        
    }
    
    
    
    return prototypeCell;
}





#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

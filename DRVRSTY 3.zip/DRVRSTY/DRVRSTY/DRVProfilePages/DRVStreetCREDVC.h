//
//  DRVStreetCREDVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 15/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVStreetCREDVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    NSUserDefaults *def;
}
@property(strong,nonatomic) IBOutlet UITableView *tblNew;

@property(strong,nonatomic) IBOutlet UILabel *lbl_header;
@property(strong,nonatomic) NSString *str_header;

@end

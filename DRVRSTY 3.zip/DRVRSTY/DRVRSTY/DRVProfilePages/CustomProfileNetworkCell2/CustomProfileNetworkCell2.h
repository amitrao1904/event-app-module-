//
//  CustomProfileNetworkCell2.h
//  DRVRSTY
//
//  Created by Macbook pro on 13/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomProfileNetworkCell2 : UITableViewCell
@property(strong,nonatomic) IBOutlet UIButton *btn_follow;
@end

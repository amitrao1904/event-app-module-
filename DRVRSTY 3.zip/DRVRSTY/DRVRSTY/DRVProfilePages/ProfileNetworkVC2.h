//
//  ProfileNetworkVC2.h
//  DRVRSTY
//
//  Created by Macbook pro on 13/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileNetworkVC2 : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    NSUserDefaults *def;
}
@property(strong,nonatomic) IBOutlet UITableView *tblNew;


@end

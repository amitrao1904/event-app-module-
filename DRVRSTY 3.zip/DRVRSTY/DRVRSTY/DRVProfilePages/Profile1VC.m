//
//  Profile1VC.m
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "Profile1VC.h"
#import "CustomProfile1Cell.h"
@interface Profile1VC ()
{
    CustomProfile1Cell *prototypeCell;
    
}
@end

@implementation Profile1VC
@synthesize tblNew,btn_yourcrew,btn_editprofile;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    btn_editprofile.layer.cornerRadius=0;
    btn_editprofile.layer.borderColor=[UIColor whiteColor].CGColor;
    btn_editprofile.layer.borderWidth=1;
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods




#pragma mark - Action Method
- (IBAction)yourcrew_Action:(id)sender {
    
    
    DRVYourCrewsVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVYourCrewsVC"];
    [self.navigationController pushViewController:login animated:true];
}
- (IBAction)edit_Action:(id)sender {
    
    
    ProfileEditProfileVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileEditProfileVC"];
    [self.navigationController pushViewController:login animated:true];
}
- (IBAction)menu_Action:(id)sender
{
    
    DRVSetting1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting1VC"];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController pushViewController:addinvController animated:NO];
    
    
}
- (IBAction)specs_Action:(id)sender
{
    ProfileVC7 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileVC7"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)photos_Action:(id)sender
{
    ProfilePhotos18VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfilePhotos18VC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
    
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomProfile1Cell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([CustomProfile1Cell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[CustomProfile1Cell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([CustomProfile1Cell class])];
    }
    
    
    prototypeCell.btn_8SC.tag = indexPath.row;
    [prototypeCell.btn_8SC addTarget:self action:@selector(yourSCClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    prototypeCell.btn_comment.tag = indexPath.row;
    [prototypeCell.btn_comment addTarget:self action:@selector(yourCommentButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    
    return prototypeCell;
}

-(void)yourSCClicked:(UIButton*)btn
{
    DRVStreetCREDVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVStreetCREDVC"];
    [self.navigationController pushViewController:login animated:true];
}
-(void)yourCommentButtonClicked:(UIButton*)btn
{
    DRVFeedCommentVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedCommentVC"];
     [self.navigationController pushViewController:login animated:true];
}
#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  CustomEditProfileCellA.h
//  DRVRSTY
//
//  Created by Macbook pro on 02/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomEditProfileCellA : UITableViewCell
@property(strong,nonatomic)IBOutlet UITextField *txt_username;
@property(strong,nonatomic)IBOutlet UITextField *txt_location;
@property(strong,nonatomic)IBOutlet UITextField *txt_email;
@property(strong,nonatomic)IBOutlet UITextField *txt_phone;

@property(strong,nonatomic)IBOutlet UITextField *txt_year;
@property(strong,nonatomic)IBOutlet UITextField *txt_make;
@property(strong,nonatomic)IBOutlet UITextField *txt_model;


@property(strong,nonatomic)IBOutlet UIButton *btn_applychanges;
@property(strong,nonatomic)IBOutlet UIButton *btn_changeprofile;
@end

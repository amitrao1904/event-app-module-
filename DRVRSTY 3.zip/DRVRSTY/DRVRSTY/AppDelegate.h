//
//  AppDelegate.h
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//
//407032

#pragma mark - Custom Method
#pragma mark - API Methods
#pragma mark - Action Method
#pragma mark - Memory CleanUP

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIStoryboard *storyboard;
    
}
@property (strong, nonatomic) UIWindow *window;
@property (strong,nonatomic) UINavigationController *nav;

- (void)showHUDWithTxt:(NSString *)hudTitle onView:(UIView *)view;
- (void)hideHUDFromView:(UIView *)view;


@property (nonatomic, assign) BOOL bNetworkAvailable;


AppDelegate *appDelegate(void);

@end


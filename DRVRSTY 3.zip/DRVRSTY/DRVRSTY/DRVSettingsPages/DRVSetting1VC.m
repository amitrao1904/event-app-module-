//
//  DRVSetting1VC.m
//  DRVRSTY
//
//  Created by Macbook pro on 10/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVSetting1VC.h"

@interface DRVSetting1VC ()

@end

@implementation DRVSetting1VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
- (IBAction)cross_Action:(id)sender
{
//    DRVFeedVC *signup = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
//    [self.navigationController pushViewController:signup animated:YES];
    
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)logout_Action:(id)sender {
    
    def = [NSUserDefaults standardUserDefaults];
    [def setBool:NO forKey:@"IS_LOGIN"];
    
    [def synchronize];
    
    LoginVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

-(IBAction)profile_Action:(id)sender
{
    Profile1VC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"Profile1VC"];
    [self.navigationController pushViewController:login animated:true];
}
-(IBAction)network_Action:(id)sender
{
    ProfileNetworkVC1 *login = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileNetworkVC1"];
    [self.navigationController pushViewController:login animated:true];

}
-(IBAction)crew_Action:(id)sender
{
    CrewVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewVC"];
    [self.navigationController pushViewController:login animated:true];
}
-(IBAction)events_Action:(id)sender
{
    
    DRVEventVC1 *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVEventVC1"];
    [self.navigationController pushViewController:login animated:true];
}
- (IBAction)inapp_Action:(id)sender
{
    
    
}
- (IBAction)setting_Action:(id)sender {
    
    DRVSetting2VC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting2VC"];
    [self.navigationController pushViewController:login animated:true];
}
- (IBAction)tutorial_Action:(id)sender {
    
    TutorialHelpVC *login = [self.storyboard instantiateViewControllerWithIdentifier:@"TutorialHelpVC"];
    [self.navigationController pushViewController:login animated:true];
    
}



#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

//
//  SettingHelpCeterVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 11/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SettingHelpCeterVC.h"
#import "CustomSettingHelpCell.h"
@interface SettingHelpCeterVC ()
{
    CustomSettingHelpCell *prototypeCell;
    
}

@end

@implementation SettingHelpCeterVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    array_list=[[NSMutableArray alloc]init];
    
    [array_list addObject:@"FAQ"];
    [array_list addObject:@"Settings"];
    [array_list addObject:@"Privacy & Safety"];
    
    
    array_list1=[[NSMutableArray alloc]init];
    [array_list1 addObject:@"1"];
    [array_list1 addObject:@"2"];
    [array_list1 addObject:@"2"];
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechanical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)notification1_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomSettingHelpCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([CustomSettingHelpCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[CustomSettingHelpCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([CustomSettingHelpCell class])];
    }
    
    prototypeCell.lbl_name.text=[array_list objectAtIndex:indexPath.row];
    
    NSString *str=[array_list1 objectAtIndex:indexPath.row];
    
    if ([str isEqualToString:@"1"]) {
        
        [prototypeCell.btn_help setImage:[UIImage imageNamed:@"thick-icon"] forState:UIControlStateNormal];
        
    }
    else
    {
        
        [prototypeCell.btn_help setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
    
    return prototypeCell;
}


#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

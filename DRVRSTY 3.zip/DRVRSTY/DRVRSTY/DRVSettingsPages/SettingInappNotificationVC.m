//
//  SettingInappNotificationVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SettingInappNotificationVC.h"
#import "CustomInappnotiCell.h"
#import "CustomInappnotiCell1.h"
@interface SettingInappNotificationVC ()
{
    CustomInappnotiCell *prototypeCell;
    CustomInappnotiCell1 *prototypeCell1;
    
}
@end

@implementation SettingInappNotificationVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    array_list=[[NSMutableArray alloc]init];
    array_list1=[[NSMutableArray alloc]init];
    
    
    
    [array_list addObject:@"Comments"];
    [array_list addObject:@"Mentions"];
    [array_list addObject:@"Streed Cred"];
    [array_list addObject:@"New Followers"];
    [array_list addObject:@"Events"];
    [array_list addObject:@"Crew"];
    [array_list addObject:@"Messages"];
    
    [array_list1 addObject:@"Receive a push notification when other users comment on your posts."];
    [array_list1 addObject:@"Receive a push notification when other users mention you in a post or tag you in a photo"];
    [array_list1 addObject:@"Receive a push notification when other users give you street cred"];
    [array_list1 addObject:@"Receive a push notification when other users follow you"];
    [array_list1 addObject:@"Receive a push notification when you are sent an invitation to an event"];
    [array_list1 addObject:@"Receive a push notification when you are sent an invitation to join a crew or once you have been accepted into a crew"];
    [array_list1 addObject:@"Receive a push notification when other users send you a message"];
    
    
    
    
    
    
    
    
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method


#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechanical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)notification1_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if(section == 0)
    {
        
        return [array_list count];
    }
    
    
    else
    {
        
        
        return 1;
    }

    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (CustomInappnotiCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([CustomInappnotiCell class])];
    
    prototypeCell1 = (CustomInappnotiCell1 *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([CustomInappnotiCell1 class])];
    
    if (indexPath.section == 0)
    {
        prototypeCell.lable1.text=[array_list objectAtIndex:indexPath.row];
        prototypeCell.lable2.text=[array_list1 objectAtIndex:indexPath.row];
        return prototypeCell;

    }
    else
    {
    return prototypeCell1;
    
    }
    
    
    
    
    
}


#pragma mark - Memory CleanUP

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

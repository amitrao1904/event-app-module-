//
//  SettingInappNotification1VC.h
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingInappNotification1VC : UIViewController

@end

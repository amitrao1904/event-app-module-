//
//  CustomSettingHelpCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 11/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomSettingHelpCell.h"

@implementation CustomSettingHelpCell
@synthesize lbl_name,btn_help;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

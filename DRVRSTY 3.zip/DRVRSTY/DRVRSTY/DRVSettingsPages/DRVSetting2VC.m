//
//  DRVSetting2VC.m
//  DRVRSTY
//
//  Created by Macbook pro on 10/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVSetting2VC.h"

@interface DRVSetting2VC ()

@end

@implementation DRVSetting2VC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method


#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)account_Action:(id)sender {
    
    SettingAccountVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingAccountVC"];
//    CATransition *transition = [CATransition animation];
//    transition.duration = 0.3;
//    transition.type = kCATransitionFade;
//    //transition.subtype = kCATransitionFromTop;
//    
//    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:YES];
    
}
- (IBAction)notification_Action:(id)sender {
    
    SettingNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingNotificationVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)blocked_Action:(id)sender {
    
    SettingBlockedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingBlockedVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)location_Action:(id)sender {
    
    SettingLocationPrivacyVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingLocationPrivacyVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)language_Action:(id)sender {
    
    SettingLanguageVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingLanguageVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)cruise_Action:(id)sender {
    
    SettingCruiseVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingCruiseVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}

- (IBAction)sound_Action:(id)sender {
    
    SettingSoundVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingSoundVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)help_Action:(id)sender {
    
    SettingHelpCeterVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingHelpCeterVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)report_Action:(id)sender {
    
    SettingReportProblemVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingReportProblemVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)contact_Action:(id)sender {
    
    DRVContactUSVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVContactUSVC"];
    [self.navigationController pushViewController:addinvController animated:YES];
}
- (IBAction)logout_Action:(id)sender
{
    LoginVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechanical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)notification1_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}



#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

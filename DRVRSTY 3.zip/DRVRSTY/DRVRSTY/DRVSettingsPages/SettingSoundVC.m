//
//  SettingSoundVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SettingSoundVC.h"

@interface SettingSoundVC ()

@end

@implementation SettingSoundVC
@synthesize btn_on,btn_off;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    btn_on.layer.cornerRadius=0;
    btn_on.layer.borderWidth=1;
    btn_on.layer.borderColor=[UIColor whiteColor].CGColor;
    
    
    btn_off.layer.cornerRadius=0;
    btn_off.layer.borderWidth=1;
    btn_off.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_off.backgroundColor=[UIColor whiteColor];
    [btn_off setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method



#pragma mark - API Methods
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Action Method
- (IBAction)on_Action:(id)sender {
    
    
    btn_on.backgroundColor=[UIColor whiteColor];
    [btn_on setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_off.backgroundColor=[UIColor clearColor];
    [btn_off setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}
- (IBAction)off_Action:(id)sender {
    
    btn_off.backgroundColor=[UIColor whiteColor];
    [btn_off setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    btn_on.backgroundColor=[UIColor clearColor];
    [btn_on setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechanical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)notification1_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}



#pragma mark - Memory CleanUP


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

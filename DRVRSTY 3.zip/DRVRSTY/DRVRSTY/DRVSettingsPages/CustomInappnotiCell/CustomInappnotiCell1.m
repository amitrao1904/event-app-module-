//
//  CustomInappnotiCell1.m
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustomInappnotiCell1.h"

@implementation CustomInappnotiCell1
@synthesize lable1,lable2,lable3,btn_right1,btn_right2;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

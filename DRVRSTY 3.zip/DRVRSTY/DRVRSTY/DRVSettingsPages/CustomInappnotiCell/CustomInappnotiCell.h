//
//  CustomInappnotiCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomInappnotiCell : UITableViewCell
@property(strong,nonatomic) IBOutlet UILabel *lable1;
@property(strong,nonatomic) IBOutlet UILabel *lable2;
@property(strong,nonatomic) IBOutlet UIButton *btn_right;
@end

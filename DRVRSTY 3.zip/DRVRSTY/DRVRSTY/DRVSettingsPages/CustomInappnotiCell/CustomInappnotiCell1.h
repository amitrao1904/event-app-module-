//
//  CustomInappnotiCell1.h
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomInappnotiCell1 : UITableViewCell
@property(strong,nonatomic) IBOutlet UILabel *lable1;
@property(strong,nonatomic) IBOutlet UILabel *lable2;
@property(strong,nonatomic) IBOutlet UILabel *lable3;
@property(strong,nonatomic) IBOutlet UIButton *btn_right1;
@property(strong,nonatomic) IBOutlet UIButton *btn_right2;
@end

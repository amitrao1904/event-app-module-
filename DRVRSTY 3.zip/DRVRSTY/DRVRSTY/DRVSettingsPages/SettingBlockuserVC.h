//
//  SettingBlockuserVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 11/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingBlockuserVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    NSUserDefaults *def;
}
@property(strong,nonatomic) IBOutlet UITableView *tblNew;

@end

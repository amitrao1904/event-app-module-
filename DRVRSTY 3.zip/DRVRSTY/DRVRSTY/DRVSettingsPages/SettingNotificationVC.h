//
//  SettingNotificationVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 10/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingNotificationVC : UIViewController

@end

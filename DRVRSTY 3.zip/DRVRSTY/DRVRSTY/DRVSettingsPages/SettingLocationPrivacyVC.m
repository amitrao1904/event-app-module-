//
//  SettingLocationPrivacyVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 10/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SettingLocationPrivacyVC.h"

@interface SettingLocationPrivacyVC ()

@end

@implementation SettingLocationPrivacyVC
@synthesize btn_accept1,btn_accept2,btn_decline1,btn_decline2;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    btn_accept1.layer.borderWidth=1;
    btn_accept1.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_accept2.layer.borderWidth=1;
    btn_accept2.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_decline1.layer.borderWidth=1;
    btn_decline1.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_decline2.layer.borderWidth=1;
    btn_decline2.layer.borderColor=[UIColor whiteColor].CGColor;
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method


#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechanical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)notification1_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
-(IBAction)accept1_Action:(id)sender
{

    btn_accept1.backgroundColor=[UIColor whiteColor];
    [btn_accept1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_decline1.backgroundColor=[UIColor clearColor];
    [btn_decline1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];


}
-(IBAction)decline1_Action:(id)sender
{

    btn_accept1.backgroundColor=[UIColor clearColor];
    [btn_accept1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_decline1.backgroundColor=[UIColor whiteColor];
    [btn_decline1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
}

-(IBAction)accept2_Action:(id)sender
{

    btn_accept2.backgroundColor=[UIColor whiteColor];
    [btn_accept2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_decline2.backgroundColor=[UIColor clearColor];
    [btn_decline2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];


}
-(IBAction)decline2_Action:(id)sender
{
    btn_accept2.backgroundColor=[UIColor clearColor];
    [btn_accept2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_decline2.backgroundColor=[UIColor whiteColor];
    [btn_decline2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}


#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

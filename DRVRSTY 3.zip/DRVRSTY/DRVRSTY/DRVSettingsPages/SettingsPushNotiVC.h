//
//  SettingsPushNotiVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 10/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsPushNotiVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    NSUserDefaults *def;
}
@property(strong,nonatomic) IBOutlet UITableView *tblNew;


@end

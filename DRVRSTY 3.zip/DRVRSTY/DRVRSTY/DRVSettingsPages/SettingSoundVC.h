//
//  SettingSoundVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingSoundVC : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btn_on;
@property (weak, nonatomic) IBOutlet UIButton *btn_off;



@end

//
//  SettingLanguageVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 11/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingLanguageVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *array_list;
    NSMutableArray *array_list1;
    NSUserDefaults *def;
}
@property(strong,nonatomic) IBOutlet UITableView *tblNew;

@end

//
//  SettingCruiseVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "SettingCruiseVC.h"

@interface SettingCruiseVC ()

@end

@implementation SettingCruiseVC
@synthesize btn_km,btn_2km,btn_5km,btn_day,btn_10km,btn_miles,btn_night,btn_automatic;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    btn_miles.layer.borderWidth=1;
    btn_miles.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_km.layer.borderWidth=1;
    btn_km.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_2km.layer.borderWidth=1;
    btn_2km.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_5km.layer.borderWidth=1;
    btn_5km.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_10km.layer.borderWidth=1;
    btn_10km.layer.borderColor=[UIColor whiteColor].CGColor;
    
    
    btn_day.layer.borderWidth=1;
    btn_day.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_night.layer.borderWidth=1;
    btn_night.layer.borderColor=[UIColor whiteColor].CGColor;
    
    btn_automatic.layer.borderWidth=1;
    btn_automatic.layer.borderColor=[UIColor whiteColor].CGColor;
    
    
    // Do any additional setup after loading the view.
}


#pragma mark - Custom Method



#pragma mark - API Methods





#pragma mark - Action Method

-(IBAction)miles_Action:(id)sender
{

    btn_miles.backgroundColor=[UIColor whiteColor];
    [btn_miles setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_km.backgroundColor=[UIColor clearColor];
    [btn_km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];

}
-(IBAction)km_Action:(id)sender
{

    btn_miles.backgroundColor=[UIColor clearColor];
    [btn_miles setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_km.backgroundColor=[UIColor whiteColor];
    [btn_km setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    

}


-(IBAction)twokm_Action:(id)sender
{
    
    btn_2km.backgroundColor=[UIColor whiteColor];
    [btn_2km setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_5km.backgroundColor=[UIColor clearColor];
    [btn_5km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_10km.backgroundColor=[UIColor clearColor];
    [btn_10km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];

}
-(IBAction)fivekm_Action:(id)sender
{
    btn_5km.backgroundColor=[UIColor whiteColor];
    [btn_5km setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    btn_2km.backgroundColor=[UIColor clearColor];
    [btn_2km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_10km.backgroundColor=[UIColor clearColor];
    [btn_10km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}
-(IBAction)tenkm_Action:(id)sender
{
    
    btn_10km.backgroundColor=[UIColor whiteColor];
    [btn_10km setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    btn_5km.backgroundColor=[UIColor clearColor];
    [btn_5km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_2km.backgroundColor=[UIColor clearColor];
    [btn_2km setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}

-(IBAction)day_Action:(id)sender
{
    
    btn_day.backgroundColor=[UIColor whiteColor];
    [btn_day setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    btn_night.backgroundColor=[UIColor clearColor];
    [btn_night setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_automatic.backgroundColor=[UIColor clearColor];
    [btn_automatic setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}
-(IBAction)automatic_Action:(id)sender
{
    
    btn_automatic.backgroundColor=[UIColor whiteColor];
    [btn_automatic setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    btn_night.backgroundColor=[UIColor clearColor];
    [btn_night setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_day.backgroundColor=[UIColor clearColor];
    [btn_day setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}
-(IBAction)night_Action:(id)sender
{
    btn_night.backgroundColor=[UIColor whiteColor];
    [btn_night setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    btn_automatic.backgroundColor=[UIColor clearColor];
    [btn_automatic setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    btn_day.backgroundColor=[UIColor clearColor];
    [btn_day setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}


-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)chat_Action:(id)sender {
    
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
- (IBAction)mechanical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
    
}
- (IBAction)notification1_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}



#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

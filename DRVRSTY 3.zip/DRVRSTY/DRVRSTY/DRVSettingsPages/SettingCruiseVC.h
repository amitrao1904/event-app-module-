//
//  SettingCruiseVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 12/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingCruiseVC : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btn_miles;
@property (weak, nonatomic) IBOutlet UIButton *btn_km;

@property (weak, nonatomic) IBOutlet UIButton *btn_2km;
@property (weak, nonatomic) IBOutlet UIButton *btn_5km;
@property (weak, nonatomic) IBOutlet UIButton *btn_10km;
@property (weak, nonatomic) IBOutlet UIButton *btn_day;
@property (weak, nonatomic) IBOutlet UIButton *btn_automatic;
@property (weak, nonatomic) IBOutlet UIButton *btn_night;



@end

//
//  DRVFeedCustomCell1.m
//  DRVRSTY
//
//  Created by Macbook pro on 03/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVFeedCustomCell1.h"

@implementation DRVFeedCustomCell1
@synthesize lable1,lable2,img_profile,view1,btn_arrow,btn_hrs,btn_sc1,btn_sc2,btn_image,btn_comment1,btn_comment2,lbl_user,lbl_status,img_profile1,view2,btn_profileimage;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

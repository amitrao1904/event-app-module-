//
//  DRVFeedCustomCell2.h
//  DRVRSTY
//
//  Created by Macbook pro on 03/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVFeedCustomCell2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img_profile;
@property (strong, nonatomic) IBOutlet UILabel *lable1;
@property (strong, nonatomic) IBOutlet UIButton *btn_hrs;
@property (strong, nonatomic) IBOutlet UILabel *lable2;
@property (strong, nonatomic) IBOutlet UIButton *btn_arrow;
@property (strong, nonatomic) IBOutlet UILabel *lbl_user;

@property (strong, nonatomic) IBOutlet UIButton *btn_sc1;
@property (strong, nonatomic) IBOutlet UIButton *btn_comment1;

@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;
@property (strong, nonatomic) IBOutlet UIButton *btn_image;

@property (strong, nonatomic) IBOutlet UILabel *lbl_status;
@property (strong, nonatomic) IBOutlet UIButton *btn_sc2;
@property (strong, nonatomic) IBOutlet UIButton *btn_comment2;
@property (weak, nonatomic) IBOutlet UIImageView *img_profile1;

@property (strong, nonatomic) IBOutlet UIButton *btn_profileimage;
@end

//
//  DRVFeedCustomCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 03/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVFeedCustomCell.h"

@implementation DRVFeedCustomCell
@synthesize img_profile,txt_write,btn_camera;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

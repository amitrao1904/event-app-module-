//
//  DRVFeedCustomCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 03/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVFeedCustomCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img_profile;
@property (strong, nonatomic) IBOutlet UITextField *txt_write;
@property (strong, nonatomic) IBOutlet UIButton *btn_camera;

@end

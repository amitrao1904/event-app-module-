//
//  DRVFeedCommentCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVFeedCommentCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btn_sc;
@end

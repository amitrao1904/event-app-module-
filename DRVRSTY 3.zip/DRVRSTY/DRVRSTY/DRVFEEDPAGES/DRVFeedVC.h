//
//  DRVFeedVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 28/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QRCodeReaderDelegate.h"
@interface DRVFeedVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate, UIActionSheetDelegate,UIScrollViewDelegate,UIDocumentInteractionControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,QRCodeReaderDelegate>
{
    
    NSMutableArray *array_list1;
    NSMutableArray *array_list2;
    NSMutableArray *array_list3;
    NSMutableArray *array_list4;
    NSUserDefaults *def;
    
    BOOL imageflag;
    UIImage *finalImage;
    NSData *dataImage;
    IBOutlet UIButton *postImage;
    NSData *imageData;
    NSData *eventImageData1;
    
    NSDictionary *mydictdata;
  //  IBOutlet    QRCodeReader    *qrCodeView;
    
}
@property (weak, nonatomic) IBOutlet UITextField *txt_search;

@property (strong, nonatomic) IBOutlet UITableView *tblNew;

@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;
@property (strong, nonatomic) IBOutlet UIView *view3;
@property (strong, nonatomic) IBOutlet UIView *view4;
@property (strong, nonatomic) IBOutlet UIView *view5;
@property (strong, nonatomic) IBOutlet UIView *view6;
@property (strong, nonatomic) IBOutlet UIButton *btn_cross;
@property (strong, nonatomic) IBOutlet UIButton *btn_post;
@property (strong, nonatomic) IBOutlet UIImageView *imageview1;
@property (strong, nonatomic) IBOutlet UIImageView *imageview2;
@property (strong, nonatomic) NSString *access_tokennn;
@end

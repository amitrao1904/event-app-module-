//
//  LoginVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 04/04/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "LoginVC.h"
#import "QRCodeReaderViewController.h"
#import "QRCodeReader.h"
#define METERS_MILE 1609.344
#define METERS_FEET 3.28084
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH,0)
#define kBaseUrl @"http://maps.googleapis.com/maps/api/directions/json?"
@interface LoginVC ()
{
    NSDictionary *dictRouteInfo;
    NSString *startPoint;
    NSString *endPoint;
    NSMutableArray *wayPoints;
    NSMutableDictionary *dict;
    NSMutableArray *Location_Array;
    CLGeocoder *geocoder;
    CLPlacemark *placemark;
    NSString *str_curent_addrs;
    
}
@end

@implementation LoginVC
@synthesize btn_login,btn_signup,img_logo,img_background;
@synthesize lattitude,longitude,dictProduct,mapView,locationManager,startLocation,address;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    def=[NSUserDefaults standardUserDefaults];


    NSString* uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString]; // IOS 6+
    NSLog(@"UDID:: %@", uniqueIdentifier);


    [def setObject:uniqueIdentifier forKey:@"uniqueIdentifierID"];


    self.img_background.backgroundColor=BACKGROUNDCOLOR;
    //btn_login.backgroundColor=[UIColor blackColor];
    btn_login.layer.cornerRadius=0;
    btn_login.layer.masksToBounds=YES;
    btn_login.layer.borderWidth = 1;
    btn_login.layer.borderColor = [UIColor colorWithRed:36/255.0f green:114/255.0f blue:212/255.0f alpha:1.0f].CGColor;

    
    
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated
{
    
    
    self.mapView.delegate=self;
    self.mapView.mapType=MKMapTypeStandard;
    //[mapview setMapType:MKMapTypeStandard];
    [self.mapView setZoomEnabled:YES];
    [self.mapView setScrollEnabled:YES];
    self.mapView.showsUserLocation=YES;
    
    
    [[self mapView] setShowsUserLocation:YES];
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    [[self locationManager] setDelegate:self];
    
    // we have to setup the location maanager with permission in later iOS versions
    if ([[self locationManager] respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [[self locationManager] requestWhenInUseAuthorization];
    }
    
    // [[self locationManager] setDesiredAccuracy:kCLLocationAccuracyBest];
    [self.locationManager startUpdatingLocation];
    
    self.locationManager.delegate = self;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    //locationManager.distanceFilter = kCLDistanceFilterNone;
    self.locationManager.pausesLocationUpdatesAutomatically=NO;
    
    
    
    
    
    
}
-(void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    
    [self.locationManager stopUpdatingLocation];
    
    CLLocation *location = [locations lastObject];
    
    def = [NSUserDefaults standardUserDefaults];
    NSString *lat=[NSString stringWithFormat:@"%.6f", location.coordinate.latitude];
    NSString *longgg=[NSString stringWithFormat:@"%.6f", location.coordinate.longitude];
    
    NSLog(@"lat.....%@",lat);
    NSLog(@"longgg.....%@",longgg);
    
    
    [def setObject:lat forKey:@"lattitude"];
    [def setObject:longgg forKey:@"longitude"];
    
//    if (!endPoint) {
//        [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
//            NSLog(@"Found placemarks: %@, error: %@", placemarks, error);
//            if (error == nil && [placemarks count] > 0) {
//                
//                placemark = [placemarks lastObject];
//                
//                NSString *locatedAt = [[placemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];
//                str_curent_addrs = [[NSString alloc]initWithString:locatedAt];
//                
//                
//                NSLog(@"address.......%@",str_curent_addrs);
//                
//                //*> Source location pin
//                MKPointAnnotation *sourceAnnotation = [[MKPointAnnotation alloc]init];
//                sourceAnnotation.coordinate=location.coordinate;
//                sourceAnnotation.title=@"Current Location";
//                sourceAnnotation.subtitle = str_curent_addrs;
//                [mapView addAnnotation:sourceAnnotation];
//                
//                CLLocationCoordinate2D destCordinate = CLLocationCoordinate2DMake([lattitude doubleValue], [longitude doubleValue]);
//                //*> Destination location pin
//                MKPointAnnotation *destAnnotation = [[MKPointAnnotation alloc]init];
//                destAnnotation.coordinate=destCordinate;
//                destAnnotation.title=@"Hotel Location";
//                destAnnotation.subtitle = address;
//                
//                
//                [mapView addAnnotation:destAnnotation];
//                
//                
//            } else {
//                NSLog(@"%@", error.debugDescription);
//            }
//        } ];
//        
//        // startPoint =str_curent_addrs;
//        //startPoint =@"123, Old palasiya Indore M.P 452001";
//        endPoint = address;
//        dispatch_async(kBgQueue, ^{
//            [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
//            NSString *strUrl;
//            strUrl=[NSString stringWithFormat:@"%@origin=%@,%@&destination=%f,%f&sensor=true",kBaseUrl,lattitude,longitude,location.coordinate.latitude, location.coordinate.longitude];
//            NSLog(@"%@",strUrl);
//            strUrl=[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//            NSData *data =[NSData dataWithContentsOfURL:[NSURL URLWithString:strUrl]];
//            [self performSelectorOnMainThread:@selector(fetchedData:) withObject:data waitUntilDone:YES];
//        });
//        
//        MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, 2*METERS_MILE, 2*METERS_MILE);
//        [[self mapView] setRegion:viewRegion animated:YES];
//    }
}


#pragma mark - Custom Method


#pragma mark - API Methods


#pragma mark - Action Method
- (IBAction)login_Action:(id)sender
{
//    CrewVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"CrewVC"];
//    CATransition *transition = [CATransition animation];
//    transition.duration = 0.3;
//    transition.type = kCATransitionFade;
//    //transition.subtype = kCATransitionFromTop;
//    
//    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
//    [self.navigationController pushViewController:addinvController animated:NO];
    
    
    LoginController *login = [self.storyboard instantiateViewControllerWithIdentifier:@"login"];
    [self.navigationController pushViewController:login animated:true];
    
    
    
    
//    if ([QRCodeReader supportsMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]]) {
//        static QRCodeReaderViewController *vc = nil;
//        static dispatch_once_t onceToken;
//        
//        dispatch_once(&onceToken, ^{
//            QRCodeReader *reader = [QRCodeReader readerWithMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]];
//            vc                   = [QRCodeReaderViewController readerWithCancelButtonTitle:@"Cancel" codeReader:reader startScanningAtLoad:YES showSwitchCameraButton:YES showTorchButton:YES];
//            vc.modalPresentationStyle = UIModalPresentationFormSheet;
//        });
//        vc.delegate = self;
//        
//        [vc setCompletionWithBlock:^(NSString *resultAsString) {
//            NSLog(@"Completion with result: %@", resultAsString);
//        }];
//        
//        [self presentViewController:vc animated:YES completion:NULL];
//    }
//    else {
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Reader not supported by the current device" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        
//        [alert show];
//    }

    
    
}
- (IBAction)signup_Action:(id)sender
{
//    Profile1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"Profile1VC"];
//    CATransition *transition = [CATransition animation];
//    transition.duration = 0.3;
//    transition.type = kCATransitionFade;
//    //transition.subtype = kCATransitionFromTop;
//    
//    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
//    [self.navigationController pushViewController:addinvController animated:NO];
    
    
    RegisterController *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"register"];
    [self.navigationController pushViewController:registercontroller animated:true];
}


//#pragma mark - QRCodeReader Delegate Methods
//
//- (void)reader:(QRCodeReaderViewController *)reader didScanResult:(NSString *)result
//{
//    [reader stopScanning];
//    
//    [self dismissViewControllerAnimated:YES completion:^{
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"QRCodeReader" message:result delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        [alert show];
//    }];
//}
//
//- (void)readerDidCancel:(QRCodeReaderViewController *)reader
//{
//    [self dismissViewControllerAnimated:YES completion:NULL];
//}

#pragma mark - Memory CleanUP

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

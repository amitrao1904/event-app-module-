//
//  ChangePasswordController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "ChangePasswordController.h"

@interface ChangePasswordController ()
@property (weak, nonatomic) IBOutlet UITextField *txt_oldpass;
@property (weak, nonatomic) IBOutlet UITextField *txt_pass;
@property (weak, nonatomic) IBOutlet UITextField *txt_retypepass;

@end

@implementation ChangePasswordController
@synthesize access_token,lable1,lable2,lable3,lable4;
- (void)viewDidLoad {
    [super viewDidLoad];
    UIColor *color = [UIColor whiteColor];
    
    lable1.hidden=YES;
    lable2.hidden=YES;
    lable3.hidden=YES;
    lable4.hidden=YES;
    
    self.txt_oldpass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Token" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_pass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"New Password" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_retypepass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Confirm Password" attributes:@{NSForegroundColorAttributeName: color}];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method
-(void) validation{
    
    if(self.txt_oldpass.text.length == 0)
    {
        
        
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Token cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        
    }
    
    else if(self.txt_pass.text.length == 0)
    {
        
        
        lable1.hidden=NO;
        lable3.hidden=NO;
        lable1.text=@"New Password cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation2:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(self.txt_retypepass.text.length == 0)
    {
        
        
        lable1.hidden=NO;
        lable4.hidden=NO;
        lable1.text=@"Retype Password cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation3:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(![self.txt_pass.text isEqualToString:self.txt_retypepass.text])
    {
    
        
        lable1.hidden=NO;
        lable4.hidden=NO;
        lable1.text=@"Confirm password cannot be match with password.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation4:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        
        return;
    }
    else
    {
    
        [self changepasswordAPI_Call];
    
    }
}
-(void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}
-(void)scrollViewScrollingwithAnimation2:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable3.hidden=YES;
    
}
-(void)scrollViewScrollingwithAnimation3:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable4.hidden=YES;
    
}
-(void)scrollViewScrollingwithAnimation4:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable4.hidden=YES;
    
}


#pragma mark - API Method
- (void)changepasswordAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    @"requestcode"                          : self.txt_oldpass.text,
                    @"Changepassword[newpassword]"          : self.txt_pass.text,
                    @"Changepassword[repeatnewpassword]"    : self.txt_retypepass.text,
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, CHANGEPASSWORD];
    
    loginURl = [NSString stringWithFormat:@"%@%@?access_token=%@", BASE_URL,CHANGEPASSWORD,[NSString stringWithFormat:@"%@",access_token]];
    
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskChangePassword currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
             lable1.hidden=YES;
             lable2.hidden=YES;
             
             [Util showAlertMessage:message withTitle:@"Alert"];
             
             LoginController *login = [self.storyboard instantiateViewControllerWithIdentifier:@"login"];
             [self.navigationController pushViewController:login animated:true];
             
         }
         
         else
         {
             @try
             {
                // [Util showAlertMessage:message withTitle:@"Alert"];
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
                 
                
                 
                 
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
                 
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         
         
     }];
}
- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}

#pragma mark - Action Method
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)actionSubmit:(id)sender
{
    [self validation];
}

#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

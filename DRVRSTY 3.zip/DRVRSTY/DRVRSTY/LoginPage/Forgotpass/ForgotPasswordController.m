//
//  ForgotPasswordController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "ForgotPasswordController.h"

@interface ForgotPasswordController ()
@property (weak, nonatomic) IBOutlet UIButton *btn_email;
@property (weak, nonatomic) IBOutlet UITextField *txt_email;

@end

@implementation ForgotPasswordController
@synthesize txt_email,btn_email,lable1,lable2;
- (void)viewDidLoad {
    [super viewDidLoad];
    lable1.hidden=YES;
    lable2.hidden=YES;
    UIColor *color = [UIColor whiteColor];
    self.txt_email.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Email or Number" attributes:@{NSForegroundColorAttributeName: color}];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method

-(void) validation{
    if(self.txt_email.text.length == 0)
    {
    
        
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Email or Phone cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else{
//        ChangePasswordController *signup = [self.storyboard instantiateViewControllerWithIdentifier:@"changepassword"];
//        [self.navigationController pushViewController:signup animated:true];

        [self forgotAPI_Call];
    }
}
-(void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}
#pragma mark - API Method
- (void)forgotAPI_Call
{
    [self.view endEditing:YES];
    
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    @"recovery"      : txt_email.text,
 
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, FORGOT];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskforgotpassword currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
         
             [Util showAlertMessage:message withTitle:@"Alert"];
             
             ChangePasswordController *login = [self.storyboard instantiateViewControllerWithIdentifier:@"changepassword"];
             login.access_token=[[response valueForKey:@"data"] valueForKey:@"auth_key"];
             [self.navigationController pushViewController:login animated:true];
             
         }
         
         else
         {
             @try
             {
                 //[Util showAlertMessage:message withTitle:@"Alert"];
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
        
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         

     }];
}
- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}

#pragma mark - Action Method
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)reset:(id)sender {
    [self validation];
    
//    PhoneSuccessController *signup = [self.storyboard instantiateViewControllerWithIdentifier:@"phonesuccess"];
//    [self.navigationController pushViewController:signup animated:true];
}
#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

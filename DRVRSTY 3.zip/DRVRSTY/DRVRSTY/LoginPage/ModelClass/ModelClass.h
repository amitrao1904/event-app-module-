//
//  ModelClass.h
//  WANNA
//
//  Created by admin on 20/08/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ModelClass : NSObject
@property(nonatomic,strong) IBOutlet NSString *Image;
@property(nonatomic,strong) IBOutlet NSString *Name;
@property(nonatomic,strong) IBOutlet NSString *Address;
@property(nonatomic,strong) IBOutlet NSString *country;
@property(nonatomic,strong) IBOutlet NSString *descrip;
@property(nonatomic,strong) IBOutlet NSString *city;
@property(nonatomic,strong) IBOutlet NSString *user_dob;
@property(nonatomic,strong) IBOutlet NSString *otheruserid;
@property(nonatomic,strong) IBOutlet NSString *messagesss;
@property(nonatomic,strong) IBOutlet NSString *sendmsgid;
@property(nonatomic,strong) IBOutlet NSString *sendmsgfrom;
@property(nonatomic,strong) IBOutlet NSString *sendmsgto;


@property(nonatomic,strong) IBOutlet NSString *country_name;
@property(nonatomic,strong) IBOutlet NSString *country_phonecode;
@property(nonatomic,strong) IBOutlet NSString *idd;
@property(nonatomic,strong) IBOutlet NSString *sortname;
@end

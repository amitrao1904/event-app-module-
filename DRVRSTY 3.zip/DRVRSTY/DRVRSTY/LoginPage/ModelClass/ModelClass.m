//
//  ModelClass.m
//  WANNA
//
//  Created by admin on 20/08/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import "ModelClass.h"

@implementation ModelClass
@synthesize Image,Name,Address,country,descrip,city,user_dob,otheruserid,messagesss,sendmsgid,sendmsgfrom,sendmsgto,country_name,country_phonecode,idd,sortname;
@end

//
//  EmailConfirmationController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "EmailConfirmationController.h"

@interface EmailConfirmationController ()
@property (weak, nonatomic) IBOutlet UITextField *txt_confirmation_token;

@end

@implementation EmailConfirmationController
@synthesize lbl_email,txt_confirmation_token,str_email,access_token,lable1,lable2;
- (void)viewDidLoad {
    [super viewDidLoad];
    lable1.hidden=YES;
    lable2.hidden=YES;
    UIColor *color = [UIColor lightGrayColor];
    self.txt_confirmation_token.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Code" attributes:@{NSForegroundColorAttributeName: color}];
    
    
    lbl_email.text=[NSString stringWithFormat:@"to %@",str_email];

    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method

-(void) validation{
    if(self.txt_confirmation_token.text.length == 0)
    {
       
                
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Confirmation Code cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;

    }
    else{
//        RegistrationVCController *registrationvc = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
//        [self.navigationController pushViewController:registrationvc animated:true];
        
        [self verifyemailAPI_Call];
    }
}
-(void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}
#pragma mark - API Method
- (void)verifyemailAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    def=[NSUserDefaults standardUserDefaults];
    NSDictionary *postParams;
    
    
    postParams =  @{
                    
//                    @"access_token"             : [NSString stringWithFormat:@"%@",access_token],
                    @"verify_code"              : txt_confirmation_token.text,
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@?access_token=%@", BASE_URL,VERIFYEMAILCODE,[NSString stringWithFormat:@"%@",access_token]];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskVerifyEmail currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
            [Util showAlertMessage:message withTitle:@"Alert"];
             
             RegistrationVCController *registrationvc = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
              registrationvc.access_token=[[response valueForKey:@"data"] valueForKey:@"auth_key"];
             registrationvc.str_emaill=str_email;
             registrationvc.emailvalid=@"emailvalid";
             
             [self.navigationController pushViewController:registrationvc animated:true];
             
         }
         
         else
         {
             @try
             {
                // [Util showAlertMessage:message withTitle:@"Alert"];
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
                 
                 
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         
         
         
     }];
}
- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}

#pragma mark - Action Method
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btn_nextAction:(id)sender {
    [self validation];
    
    
}

#pragma mark - Memory CleanUp



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

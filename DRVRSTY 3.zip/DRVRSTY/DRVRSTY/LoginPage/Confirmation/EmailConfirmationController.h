//
//  EmailConfirmationController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegistrationVCController.h"
@interface EmailConfirmationController : UIViewController
{
    
    NSUserDefaults *def;
}

@property(strong,nonatomic) IBOutlet UILabel *lbl_email;
@property(strong,nonatomic) NSString  *str_email;
@property(strong,nonatomic) NSString  *access_token;
@property (weak, nonatomic) IBOutlet UILabel *lable1;
@property (weak, nonatomic) IBOutlet UILabel *lable2;
@end

//
//  PhoneConfirmationController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "PhoneConfirmationController.h"
@interface PhoneConfirmationController ()
@property (weak, nonatomic) IBOutlet UITextField *txt_otp;

@end

@implementation PhoneConfirmationController
@synthesize txt_otp,otp,phonenumber,lbl_number,access_token,lable1,lable2;
- (void)viewDidLoad {
    [super viewDidLoad];
    lable1.hidden=YES;
    lable2.hidden=YES;
    UIColor *color = [UIColor darkGrayColor];
    
    lbl_number.text=[NSString stringWithFormat:@"+%@",phonenumber];
    
    
    self.txt_otp.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Confirmation Code" attributes:@{NSForegroundColorAttributeName: color}];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method

-(void) validation{
    if(self.txt_otp.text.length == 0)
    {
        
       
        
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Confirmation Code cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
//    if (![otp isEqualToString:self.txt_otp.text])
//        
//    {
//        [Util showAlertMessage:@"Confirmation Code not match." withTitle:@"Alert"];
//        return;
//    }
    else{
//        RegistrationVCController *registrationvc = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
//        [self.navigationController pushViewController:registrationvc animated:true];
        
        [self otpAPI_Call];
    }
}
-(void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}

#pragma mark - API Method


- (void)otpAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    @"otp"                : txt_otp.text,
                    @"format_mobile"      : [NSString stringWithFormat:@"%@",phonenumber],
                    
                    
                    };
    
    
  //  loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, MOBILEOTP];
    
    
     loginURl = [NSString stringWithFormat:@"%@%@?access_token=%@", BASE_URL,MOBILEOTP,[NSString stringWithFormat:@"%@",access_token]];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskotp currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         NSString *type=[[[response valueForKey:@"data"] valueForKey:@"otp"] valueForKey:@"type"];
         
         
         if ([type isEqualToString:@"error"])
         {
             lable1.hidden=NO;
             lable2.hidden=NO;
             lable1.text=[NSString stringWithFormat:@"%@",message];
             
             
             [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
           //  [Util showAlertMessage:message withTitle:@"Alert"];
             return;
             
         }
         
         
         if (a==1)
         {
             
               [Util showAlertMessage:message withTitle:@"Alert"];
             
             NSLog(@"....%@",response);
             
             
             RegistrationVCController *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
             
             registercontroller.access_token=[[[response valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"auth_key"];
             
             [self.navigationController pushViewController:registercontroller animated:true];
             
         }
         
         else
         {
             @try
             {
               //  [Util showAlertMessage:message withTitle:@"Alert"];
                 
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
                 
                 
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         
     }];
}
- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}


#pragma mark - Action Method
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (IBAction)btn_nextAction:(id)sender {
   [self validation];
    
    
//    RegistrationVCController *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
//    [self.navigationController pushViewController:registercontroller animated:true];
    
}
- (IBAction)resend_Action:(id)sender
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    
                    @"format_mobile"      : [NSString stringWithFormat:@"%@",phonenumber],
                   
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, RESENDOTP];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskresendotp currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
             //  [Util showAlertMessage:message withTitle:@"Alert"];
             
             
             otp=[response valueForKey:@"otp"];
             
             
             
         }
         
         else
         {
             @try
             {
                 [Util showAlertMessage:message withTitle:@"Alert"];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         
     }];

}
#pragma mark - Memory CleanUp


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  LoginController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 31/03/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "LoginController.h"

@interface LoginController ()
{
    NSUserDefaults *def;
}

@end

@implementation LoginController
@synthesize txtEmail,txtPassword,btn_show,lable1,lable2,lable3;
- (void)viewDidLoad {
    [super viewDidLoad];
    lable1.hidden=YES;
    lable2.hidden=YES;
    lable3.hidden=YES;
    
    
    UIColor *color = [UIColor whiteColor];
    txtEmail.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Email or Username" attributes:@{NSForegroundColorAttributeName: color}];
    txtPassword.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{NSForegroundColorAttributeName: color}];
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method

-(void) validation
{
    if(txtEmail.text.length == 0)
    {

        lable1.hidden=NO;
        lable3.hidden=NO;
        lable3.text=@"Email cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation11:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        
        
        
        return;
        
    }
    else if(txtPassword.text.length == 0)
    {
        
        lable2.hidden=NO;
        lable3.hidden=NO;
        btn_show.hidden=YES;
        lable3.text=@"Password cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation12:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
       
        return;
    }
    else
    {
    
//        lable1.hidden=NO;
//        lable2.hidden=NO;
//        lable3.hidden=NO;
//        btn_show.hidden=YES;
        
       [self loginAPI_Call];
    }
}


#pragma mark - API Methods
- (void)loginAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    def=[NSUserDefaults standardUserDefaults];
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    @"UserLogin[username]"      : txtEmail.text,
                    @"UserLogin[password]"      : txtPassword.text,
                    @"UserLogin[device_id]"     : [def valueForKey:@"uniqueIdentifierID"],
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URLLOGIN, LOGIN];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTasklogin currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
             //  [Util showAlertMessage:message withTitle:@"Alert"];
             
             lable1.hidden=YES;
             lable2.hidden=YES;
             lable3.hidden=YES;
             btn_show.hidden=NO;
             
             [Util showAlertMessage:message withTitle:@"Alert"];
             
             def = [NSUserDefaults standardUserDefaults];
             
             [def setBool:YES forKey:@"IS_LOGIN"];
             [def synchronize];
             
              DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
              CATransition *transition = [CATransition animation];
              transition.duration = 0.3;
              transition.type = kCATransitionFade;
              //transition.subtype = kCATransitionFromTop;
             
            // addinvController.access_tokennn=[[response valueForKey:@"data"] valueForKey:@"auth_key"];
             
             
             [def setObject:[response valueForKey:@"data"] forKey:@"logindata"];
 
              [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
              [self.navigationController pushViewController:addinvController animated:NO];
             
         }
         
         else
         {
             @try
             {
                 
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable3.hidden=NO;
                 
                 lable3.text=[NSString stringWithFormat:@"%@",message];
                 
                 btn_show.hidden=YES;
                [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
                // [Util showAlertMessage:message withTitle:@"Alert"];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
     }];
}
- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    lable3.hidden=YES;
    btn_show.hidden=NO;
    
    
}
-(void)scrollViewScrollingwithAnimation11:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable3.hidden=YES;
    btn_show.hidden=NO;
    
}
-(void)scrollViewScrollingwithAnimation12:(NSTimer *)timer
{
    lable2.hidden=YES;
    lable3.hidden=YES;
    btn_show.hidden=NO;
    
}




#pragma mark - Action Method
- (IBAction)loginView:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btn_forgotaction:(id)sender
{
    ForgotPasswordController *forgotcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"forgotpassword"];
    [self.navigationController pushViewController:forgotcontroller animated:true];

}

- (IBAction)login:(id)sender
{
    [self validation];
    
    
    
}
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)signup_Action:(id)sender {
    
    RegisterController *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"register"];
    [self.navigationController pushViewController:registercontroller animated:true];
}
-(IBAction)show_Action:(id)sender
{

    if(isPopShowing)
    {

        isPopShowing = NO;
        
        [txtPassword setSecureTextEntry:YES];
        
        [btn_show setTitle:@"SHOW" forState:UIControlStateNormal];
    }
    else
    {

        isPopShowing = YES;
        
        [txtPassword setSecureTextEntry:NO];
        
        [btn_show setTitle:@"HIDE" forState:UIControlStateNormal];
    }
    
    
}

#pragma mark - Memory CleanUp



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

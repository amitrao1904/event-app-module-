//
//  SignupController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneConfirmationController.h"
#import "SignupEmailController.h"

@interface SignupController : UIViewController<UIScrollViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate>
{

    NSUserDefaults *def;
    
    NSMutableArray *array_countryname;
    NSMutableArray *array_countrycode;
    NSMutableArray *array_sortname;
     NSMutableArray *array_id;
    
    BOOL countryFlag;
    
    CGRect toolbarTargetFrame;
    CGRect datePickerTargetFrame;
    
    UIPickerView *pickerView;
    UIToolbar *toolBar;
    UIToolbar *toolBar1;
    UIView *darkView;
    UIView *darkView1;
    
    NSString *country_id;
    
    NSString *str_code;
    
    NSMutableArray *array_alluserlist,*array_user;
    NSString *userid;
    NSArray *MSSearchArrayTitle;
    NSArray *MSSearchArrayTitle1;
    
    

}
@property (weak, nonatomic) IBOutlet UIImageView *Search_logo;
@property(strong,nonatomic) IBOutlet UIView *view_search;
@property NSMutableArray *Return_respos;
@property NSMutableArray *ArrayRestaurant;
@property(strong,nonatomic) IBOutlet UITextField *txt_search;
@property (weak, nonatomic) IBOutlet UILabel *lable1;
@property (weak, nonatomic) IBOutlet UILabel *lable2;
@property(strong,nonatomic) IBOutlet UIView *view1;
@property(strong,nonatomic) IBOutlet UITableView *tblNew;
@property(strong,nonatomic) IBOutlet UIButton *btn_countrycode;
@property(strong,nonatomic) IBOutlet UIScrollView *ScrollView;
@property(strong,nonatomic) IBOutlet UIScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UISearchDisplayController *searchdisplaycontroller;
@end

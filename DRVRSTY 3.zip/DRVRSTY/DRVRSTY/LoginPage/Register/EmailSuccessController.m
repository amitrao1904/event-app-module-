//
//  EmailSuccessController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "EmailSuccessController.h"

@interface EmailSuccessController ()

@end

@implementation EmailSuccessController
@synthesize txt_code;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method



#pragma mark - API Method


#pragma mark - Action Method

- (IBAction)btn_back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  RegisterVehicleController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneSuccessController.h"
#import "EmailSuccessController.h"

@interface RegisterVehicleController : UIViewController
{

    NSUserDefaults *def;
    
    NSString *token;
}
@property (weak, nonatomic) IBOutlet UIButton *btn_skip;
@property (weak, nonatomic) IBOutlet UILabel *lable1;
@property (weak, nonatomic) IBOutlet UILabel *lable2;
@property (weak, nonatomic) IBOutlet UILabel *lable3;
@property (weak, nonatomic) IBOutlet UILabel *lable4;
@property (weak, nonatomic) NSString *access_tokennn;
@end

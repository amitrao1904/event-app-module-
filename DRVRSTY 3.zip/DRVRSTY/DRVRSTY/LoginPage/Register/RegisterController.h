//
//  RegisterController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignupController.h"
@interface RegisterController : UIViewController
{

    NSUserDefaults *def;
    NSString *fbAccessToken;
    NSMutableArray *finalarray;
    
    NSString *email;
    
    NSString *name;
    NSString *gender ;
    NSString *aboutme;
    UIImageView *imagebb;
    NSString *googleid;
    NSString *fname;
    NSString *lname;
    NSURL *pictureURL;
    NSURL *profileurl;
    
    NSURL *pictureURLG;
    NSURL *profileurlG;
}
@end

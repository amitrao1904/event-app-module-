//
//  EmailSuccessController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmailSuccessController : UIViewController
{

    NSUserDefaults *def;
}
@property(strong,nonatomic) IBOutlet UITextField *txt_code;
@end

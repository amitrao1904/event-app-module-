//
//  RegistrationVCController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "RegistrationVCController.h"

@interface RegistrationVCController ()
@property (weak, nonatomic) IBOutlet UITextField *txt_fullname;
@property (weak, nonatomic) IBOutlet UITextField *txt_location;
@property (weak, nonatomic) IBOutlet UITextField *txt_pass;
@property (weak, nonatomic) IBOutlet UITextField *txt_confirmpass;
@property (weak, nonatomic) IBOutlet UITextField *txt_username;
@property (weak, nonatomic) IBOutlet UITextField *txt_datebirth;
@property (weak, nonatomic) IBOutlet UITextField *txt_email;

@end

@implementation RegistrationVCController
@synthesize btn_photo,imageview1,btn_dateofbirth,txt_fullname,txt_location,txt_pass,txt_username,lable1,lable2,lable3,lable4,lable5,lable6,access_token,txt_email,facebook,mydict,str_emaill,emailvalid,lable7;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    lable1.hidden=YES;
    lable2.hidden=YES;
    lable3.hidden=YES;
    lable4.hidden=YES;
    lable5.hidden=YES;
    lable6.hidden=YES;
    lable7.hidden=YES;

    
    btn_photo.layer.cornerRadius = 0;
    btn_photo.layer.masksToBounds = YES;
    btn_photo.layer.borderWidth = 1;
    btn_photo.layer.borderColor = [UIColor whiteColor].CGColor;
    
    
    if ([facebook isEqualToString:@"facebook"])
    {
        UIColor *color = [UIColor lightGrayColor];
        access_token=[mydict valueForKey:@"auth_key"];
//        self.txt_username.text=[mydict valueForKey:@"username"];
//        self.txt_fullname.text=[mydict valueForKey:@"fullname"];
        
        self.txt_username.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Username" attributes:@{NSForegroundColorAttributeName: color}];
        
        self.txt_fullname.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Full Name" attributes:@{NSForegroundColorAttributeName: color}];
        
        self.txt_email.text=[mydict valueForKey:@"email"];
        
        self.txt_email.userInteractionEnabled = NO;
        
      //  self.txt_location.text=[mydict valueForKey:@"location"];
        
        
        
       // [btn_dateofbirth setTitle:[mydict valueForKey:@"dob"] forState:UIControlStateNormal];
        [btn_dateofbirth setTitle:@"Select Date of Birth" forState:UIControlStateNormal];
        
       // dateString3=[mydict valueForKey:@"dob"];
        
        self.txt_location.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Location" attributes:@{NSForegroundColorAttributeName: color}];
        self.txt_pass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{NSForegroundColorAttributeName: color}];
        self.txt_confirmpass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Re-type Password" attributes:@{NSForegroundColorAttributeName: color}];
    }
    else if ([emailvalid isEqualToString:@"emailvalid"])
    {
        
        self.txt_email.text=[NSString stringWithFormat:@"%@",str_emaill];
        
        self.txt_email.userInteractionEnabled = NO;
        
        UIColor *color = [UIColor lightGrayColor];
        self.txt_username.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Username" attributes:@{NSForegroundColorAttributeName: color}];
        
        self.txt_fullname.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Full Name" attributes:@{NSForegroundColorAttributeName: color}];
        
        [btn_dateofbirth setTitle:@"Select Date of Birth" forState:UIControlStateNormal];
        self.txt_location.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Location" attributes:@{NSForegroundColorAttributeName: color}];
        self.txt_pass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{NSForegroundColorAttributeName: color}];
        self.txt_confirmpass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Re-type Password" attributes:@{NSForegroundColorAttributeName: color}];
    }

    
    else
    {
    
    self.txt_email.userInteractionEnabled = YES;
    
    UIColor *color = [UIColor lightGrayColor];
    self.txt_username.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Username" attributes:@{NSForegroundColorAttributeName: color}];
    
    self.txt_fullname.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Full Name" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_email.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Email" attributes:@{NSForegroundColorAttributeName: color}];
    [btn_dateofbirth setTitle:@"Select Date of Birth" forState:UIControlStateNormal];
    self.txt_location.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Location" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_pass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_confirmpass.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Re-type Password" attributes:@{NSForegroundColorAttributeName: color}];
    }
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method

-(void) validation{
    
    
    if (str_image1==nil)
    {
    
        lable1.hidden=NO;
        lable1.text=@"Please Select image.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation2:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
   else if(self.txt_username.text.length == 0)
    {
      

        lable1.hidden=NO;
        lable2.hidden=NO;
       // lable2.hidden=NO;
        lable1.text=@"User Name cannot be blank";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(self.txt_fullname.text.length == 0)
    {
       
        
        lable1.hidden=NO;
        lable3.hidden=NO;
        lable1.text=@"Full Name cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation3:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(self.txt_email.text.length == 0)
    {
        
        lable1.hidden=NO;
        lable4.hidden=NO;
        lable1.text=@"Email cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation4:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if([btn_dateofbirth.titleLabel.text isEqualToString:@"Select Date of Birth"])
    {
        
        lable1.hidden=NO;
        lable5.hidden=NO;
        lable1.text=@"Please Select DateofBirth.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation5:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(self.txt_location.text.length == 0)
    {
        
        
        lable1.hidden=NO;
        lable6.hidden=NO;
        lable1.text=@"Location cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation6:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(self.txt_pass.text.length == 0)
    {
    
        
        lable1.hidden=NO;
        lable7.hidden=NO;
        lable1.text=@"Password cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation7:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else
    {

        if ([facebook isEqualToString:@"facebook"])
        {
            [self socialprfileAPI_Call];
        }
        else
        {
        
        [self REG_API_Call];
      
        }
        
    }
}

#pragma mark - API Method
- (void)REG_API_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *registerURl;
    
    NSDictionary *postParams;
    
    def=[NSUserDefaults standardUserDefaults];
    
    
    
    
    postParams =  @{
                    @"TmpUsers[username]"       :txt_username.text,
                    @"TmpUsers[email]"          :txt_email.text,
                    @"TmpUsers[fullname]"       :txt_fullname.text,
                    @"TmpUsers[dob]"            :[NSString stringWithFormat:@"%@",dateString3],
                    @"TmpUsers[location]"       :txt_location.text,
                    @"TmpUsers[latitude]"       :[def valueForKey:@"lattitude"],
                    @"TmpUsers[longtitude]"     :[def valueForKey:@"longitude"],
                    @"TmpUsers[password]"       :txt_pass.text,
                    @"TmpUsers[avtar]"          :eventImageData1,
                    
                   };
    
    
  //  registerURl = [NSString stringWithFormat:@"%@%@", BASE_URL, PROFILE];
    
    registerURl = [NSString stringWithFormat:@"%@%@?access_token=%@", BASE_URL,PROFILE,[NSString stringWithFormat:@"%@",access_token]];
    
    
    [serviceManager multipartAPICallUsingDataTaskHTTPMethod:POST url:registerURl andParameters:postParams forTask:kTaskProfile currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int status=[[response objectForKey:@"success"]intValue];
         NSString *message=[response valueForKey:@"message"];
         if (status==1)
         {
             
             RegisterVehicleController *registervehicle = [self.storyboard instantiateViewControllerWithIdentifier:@"registervehicle"];
             
             def=[NSUserDefaults standardUserDefaults];
             
             [def setObject:[[response valueForKey:@"data"] valueForKey:@"auth_key"] forKey:@"authkey"];
             [def synchronize];
             
            
             
             [self.navigationController pushViewController:registervehicle animated:true];
            
             [Util showAlertMessage:message withTitle:@"Alert"];
             
         }
        
         
         else
         {
             @try
             {
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
                 
                 
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
                // [Util showAlertMessage:message withTitle:@"Alert"];
                
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         
         }
         
         
     }];
}

- (void)socialprfileAPI_Call
{
    [self.view endEditing:YES];
    
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    @"User[username]"       :txt_username.text,
                    @"User[email]"          :txt_email.text,
                    @"User[fullname]:"      :txt_fullname.text,
                    @"User[dob]"            :[NSString stringWithFormat:@"%@",dateString3],
                    @"User[location]"       :txt_location.text,
                    @"User[latitude]"       :[def valueForKey:@"lattitude"],
                    @"User[longtitude]"     :[def valueForKey:@"longitude"],
                    @"User[password]"       :txt_pass.text,
                    @"User[avtar]"          :eventImageData1,
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, WEB_URL_socialFbLogin];
    
    [serviceManager multipartAPICallUsingDataTaskHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskProfile currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
             RegisterVehicleController *registervehicle = [self.storyboard instantiateViewControllerWithIdentifier:@"registervehicle"];
             
             def=[NSUserDefaults standardUserDefaults];
             
             [def setObject:[[response valueForKey:@"data"] valueForKey:@"auth_key"] forKey:@"authkey"];
             [def synchronize];
             
             
             
             [self.navigationController pushViewController:registervehicle animated:true];
             
             [Util showAlertMessage:message withTitle:@"Alert"];

             
             
         }
         
         else
         {
             @try
             {
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
                 
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         
         
     }];
}

- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}
- (void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}
- (void)scrollViewScrollingwithAnimation2:(NSTimer *)timer
{
    lable1.hidden=YES;
   
    
}
- (void)scrollViewScrollingwithAnimation3:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable3.hidden=YES;
    
    
}
- (void)scrollViewScrollingwithAnimation4:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable4.hidden=YES;
    
    
}
- (void)scrollViewScrollingwithAnimation5:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable5.hidden=YES;
    
    
}
- (void)scrollViewScrollingwithAnimation6:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable6.hidden=YES;
    
    
}
- (void)scrollViewScrollingwithAnimation7:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable7.hidden=YES;
    
    
}
#pragma mark - Action Method

-(IBAction)dateofbirth_Action:(id)sender
{
    
    [sender resignFirstResponder];

    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone || [UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad)
    {    // The iOS device = iPhone or iPod Touch
        
        
        CGSize iOSDeviceScreenSize = [[UIScreen mainScreen] bounds].size;
        
        if (iOSDeviceScreenSize.height == 480)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-216-44, 320, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-216, 320, 216);
        }
        if (iOSDeviceScreenSize.height == 568)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-216-44, 320, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-216, 320, 220);
        }
        
        if (iOSDeviceScreenSize.height == 667)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-216-44, 375, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-216, 375, 224);
        }
        if (iOSDeviceScreenSize.height == 736)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-216-44, 414, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-216, 414, 228);
        }
        if (iOSDeviceScreenSize.height == 1024)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-216-44, 768, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-216, 768, 332);
        }
        
        
    }else{
        toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-216-44, 768, 44);
        datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-216, 768, 332);
    }
    
    
    
    
    
    darkView = [[UIView alloc] initWithFrame:self.view.bounds] ;
    darkView.alpha = 0;
    darkView.backgroundColor = [UIColor blackColor];
    darkView.tag = 9;
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissDatePicker:)] ;
    [darkView addGestureRecognizer:tapGesture];
    [self.view addSubview:darkView];
    
    datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height+44, 320, 216)] ;
    datePicker.tag = 10;
    datePicker.datePickerMode=UIDatePickerModeDate;
    [datePicker setMaximumDate:[NSDate date]];
    datePicker.backgroundColor=[UIColor whiteColor];
    [datePicker addTarget:self action:@selector(changeDate:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:datePicker];
    
    
    NSDateFormatter *dateformate=[[NSDateFormatter alloc]init];
    [dateformate setDateFormat:@"dd  /  MMM   /  yyyy"];
    
    //set datepicker date to selected date
    //NSString *btnDate = btn_Date.titleLabel.text;
    // datePicker.date=[dateformate dateFromString:btnDate];
    
    toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height, 320, 44)] ;
    toolBar.tag = 11;
    toolBar.barStyle = UIBarStyleBlackTranslucent;
    
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil] ;
    
    CGRect frameimg = CGRectMake(0, 0, 50, 30);
    
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    [someButton setTitle:@"Done" forState:UIControlStateNormal];
    [someButton addTarget:self action:@selector(dismissDatePicker:)
         forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *doneButton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    
    [toolBar setItems:[NSArray arrayWithObjects:spacer, doneButton, nil]];
    [self.view addSubview:toolBar];
    
    toolBar.frame = toolbarTargetFrame;
    datePicker.frame = datePickerTargetFrame;
    
    darkView.alpha = 0.5;

}

-(void)dismissDatePicker:(id)sender{
    
    CGAffineTransform transfrom = CGAffineTransformMakeTranslation(0, 200);
    
    CGAffineTransform transfrom1 = CGAffineTransformMakeTranslation(0, 260);
    
    datePicker.transform = transfrom;
    datePicker.alpha = datePicker.alpha * (-1) + 1;
    
    toolBar.transform = transfrom1;
    toolBar.alpha = toolBar.alpha * (-1) + 1;
    
    [UIView commitAnimations];
    
    [btn_dateofbirth setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    //set selected date in date field
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc]init];
    [dateFormatter2 setDateFormat:@"dd   /   MMM   /   YYYY"];
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"yyyy-MM-dd";
    
    dateString3 = [dateFormatter stringFromDate:datePicker.date];
    
    NSString *dateString2 = [dateFormatter2 stringFromDate:datePicker.date];
    [btn_dateofbirth setTitle:dateString2 forState:UIControlStateNormal];
    darkView.hidden=YES;
    
}

- (void)changeDate:(UIDatePicker *)sender {
    
    NSDateFormatter *dateformate=[[NSDateFormatter alloc]init];
    [dateformate setDateFormat:@"dd  /  MMM  /  YYYY"];
    //date=[dateformate stringFromDate:sender.date];
    
}
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_nextAction:(id)sender
{
    [self validation];
    
//    RegisterVehicleController *registervehicle = [self.storyboard instantiateViewControllerWithIdentifier:@"registervehicle"];
//    [self.navigationController pushViewController:registervehicle animated:true];
}
-(IBAction)camera_Action:(id)sender
{

    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select Image from..." delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Image Gallary", nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
    // actionSheet.alpha=0.90;
    actionSheet.tag = 1;
    [actionSheet showInView:self.view];

}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    switch (actionSheet.tag)
    {
        case 1:
            switch (buttonIndex)
        {
            case 0:
            {
#if TARGET_IPHONE_SIMULATOR
                
                UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Saw Them" message:@"Camera not available." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
                
                
#elif TARGET_OS_IPHONE
                
                UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                picker.delegate = self;
                //picker.allowsEditing = YES;
                [self presentViewController:picker animated:YES completion:nil];
                
                
#endif
            }
                break;
            case 1:
            {
                UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                picker.delegate = self;
                [self presentViewController:picker animated:YES completion:nil];
                
            }
                break;
        }
            break;
            
        default:
            break;
    }
}
-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary*)info
{
    str_image1=@"image1";
    
    finalImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    
    btn_photo.layer.borderWidth = 0;
    
    imageData = UIImageJPEGRepresentation(finalImage,0.4);
    
    postImage.contentMode = UIViewContentModeScaleAspectFit;
    
    self.imageview1.image = finalImage;
    imageview1.contentMode = UIViewContentModeScaleAspectFit;
    [self resizeImage:finalImage];
    
   // [btn_photo setImage:finalImage forState:UIControlStateNormal];
    
    
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}
-(UIImage *)resizeImage:(UIImage *)image
{
    float actualHeight = image.size.height;
    float actualWidth = image.size.width;
    float maxHeight = 300.0;
    float maxWidth = 400.0;
    float imgRatio = actualWidth/actualHeight;
    float maxRatio = maxWidth/maxHeight;
    float compressionQuality = 0.5;//50 percent compression
    
    if (actualHeight > maxHeight || actualWidth > maxWidth)
    {
        if(imgRatio < maxRatio)
        {
            //adjust width according to maxHeight
            imgRatio = maxHeight / actualHeight;
            actualWidth = imgRatio * actualWidth;
            actualHeight = maxHeight;
        }
        else if(imgRatio > maxRatio)
        {
            //adjust height according to maxWidth
            imgRatio = maxWidth / actualWidth;
            actualHeight = imgRatio * actualHeight;
            actualWidth = maxWidth;
        }
        else
        {
            actualHeight = maxHeight;
            actualWidth = maxWidth;
        }
    }
    
    CGRect rect = CGRectMake(0.0, 0.0, actualWidth, actualHeight);
    UIGraphicsBeginImageContext(rect.size);
    [image drawInRect:rect];
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    eventImageData1 = UIImageJPEGRepresentation(img, compressionQuality);
    UIGraphicsEndImageContext();
    
    return [UIImage imageWithData:eventImageData1];
    
}

#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  CustumCountryCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 25/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "CustumCountryCell.h"

@implementation CustumCountryCell
@synthesize lable1,lable2;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  CustumCountryCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 25/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustumCountryCell : UITableViewCell
@property(strong,nonatomic) IBOutlet UILabel *lable1;
@property(strong,nonatomic) IBOutlet UILabel *lable2;
@end

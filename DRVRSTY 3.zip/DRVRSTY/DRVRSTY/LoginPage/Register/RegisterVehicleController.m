//
//  RegisterVehicleController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "RegisterVehicleController.h"

@interface RegisterVehicleController ()
@property (weak,nonatomic) IBOutlet UIButton *btn_next;
@property (weak, nonatomic) IBOutlet UITextField *txt_year;
@property (weak, nonatomic) IBOutlet UITextField *txt_make;
@property (weak, nonatomic) IBOutlet UITextField *txt_model;
@property (weak, nonatomic) IBOutlet UITextField *txt_registration_nu;
@end

@implementation RegisterVehicleController
@synthesize btn_skip,lable1,lable2,lable3,lable4,access_tokennn;
- (void)viewDidLoad {
    [super viewDidLoad];
    lable1.hidden=YES;
    lable2.hidden=YES;
    lable3.hidden=YES;
    lable4.hidden=YES;
    
    NSLog(@"......%@",access_tokennn);
    
    token=[NSString stringWithFormat:@"%@",access_tokennn];
    
    self.btn_next.layer.borderWidth = 1.0f;
    self.btn_next.layer.cornerRadius = 0;
    self.btn_next.layer.borderColor = [UIColor colorWithRed:36/255.0f green:114/255.0f blue:212/255.0f alpha:1.0f].CGColor;
    
    btn_skip.layer.cornerRadius=0;
    btn_skip.layer.masksToBounds=YES;
    btn_skip.layer.borderWidth = 1;
    btn_skip.layer.borderColor = [UIColor colorWithRed:36/255.0f green:114/255.0f blue:212/255.0f alpha:1.0f].CGColor;
    
    UIColor *color = [UIColor lightGrayColor];
    self.txt_year.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Year" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_make.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Make" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_model.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Model" attributes:@{NSForegroundColorAttributeName: color}];
    self.txt_registration_nu.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Registration No." attributes:@{NSForegroundColorAttributeName: color}];

    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method

-(void) validation{
    if(self.txt_year.text.length == 0)
    {
        
        
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Year cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else if(self.txt_make.text.length == 0)
    {
        
        
        
        lable1.hidden=NO;
        lable3.hidden=NO;
        lable1.text=@"Make cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation2:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
        
    }
    else if(self.txt_model.text.length == 0)
    {
        
        
        
        lable1.hidden=NO;
        lable4.hidden=NO;
        lable1.text=@"Model cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation2:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;
        
    }
    else
    {
//        PhoneSuccessController *phonesuccess = [self.storyboard instantiateViewControllerWithIdentifier:@"phonesuccess"];
//        [self.navigationController pushViewController:phonesuccess animated:true];
        
        
        [self RegVehicleAPI_Call];
    }
}
-(void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;

    
}
-(void)scrollViewScrollingwithAnimation2:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable3.hidden=YES;
    
}
-(void)scrollViewScrollingwithAnimation3:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable4.hidden=YES;
    
}

#pragma mark - API Method
- (void)RegVehicleAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    def=[NSUserDefaults standardUserDefaults];
    
    
    postParams =  @{
                    @"Vehicles[veh_year]"      : self.txt_year.text,
                    @"Vehicles[veh_make]"      : self.txt_make.text,
                    @"Vehicles[veh_model]"     : self.txt_model.text,
                    
                    };
    
    
  //  loginURl = [NSString stringWithFormat:@"%@%@", BASE_URLVEHICLE, REGVEHICLE];
    
     loginURl = [NSString stringWithFormat:@"%@%@?access_token=%@", BASE_URLVEHICLE,REGVEHICLE,[NSString stringWithFormat:@"%@",[def valueForKey:@"authkey"]]];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskRegVehicle currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
             [Util showAlertMessage:message withTitle:@"Alert"];
             
             def = [NSUserDefaults standardUserDefaults];
             
             [def setBool:YES forKey:@"IS_LOGIN"];
             [def synchronize];
             DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
             CATransition *transition = [CATransition animation];
             transition.duration = 0.3;
             transition.type = kCATransitionFade;
             //transition.subtype = kCATransitionFromTop;
             
             [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
             [self.navigationController pushViewController:addinvController animated:NO];
             
         }
         
         else
         {
             @try
             {
                 [Util showAlertMessage:message withTitle:@"Alert"];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
         
         
     }];
}



#pragma mark - Action Method
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btn_nextAction:(id)sender {
    [self validation];
    
    
}
- (IBAction)btn_skipAction:(id)sender {
    
    def = [NSUserDefaults standardUserDefaults];
    
    [def setBool:YES forKey:@"IS_LOGIN"];
    [def synchronize];
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}


#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

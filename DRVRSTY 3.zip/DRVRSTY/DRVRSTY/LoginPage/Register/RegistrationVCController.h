//
//  RegistrationVCController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 05/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegisterVehicleController.h"

@interface RegistrationVCController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate, UIActionSheetDelegate,UIScrollViewDelegate,UIDocumentInteractionControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    BOOL imageflag;
    UIImage *finalImage;
    NSData *dataImage;
    IBOutlet UIButton *postImage;
    NSData *imageData;
    NSData *eventImageData1;
    
    NSString *str_image1;
    
    NSUserDefaults *def;
    
    NSString *dateformat12;
    
    
    //FOR DATE PICKER
    UIDatePicker *datePicker;
    UIView *darkView;
    UIToolbar *toolBar;
    IBOutlet UITextField *date;
    //END
    
    CGRect toolbarTargetFrame;
    CGRect datePickerTargetFrame;
    NSString *dateString3;
}
@property (strong,nonatomic) IBOutlet UIButton *btn_photo;
@property (strong,nonatomic) IBOutlet UIButton *btn_dateofbirth;
@property (strong, nonatomic) IBOutlet UIImageView *imageview1;

@property (weak, nonatomic) IBOutlet UILabel *lable1;
@property (weak, nonatomic) IBOutlet UILabel *lable2;
@property (weak, nonatomic) IBOutlet UILabel *lable3;
@property (weak, nonatomic) IBOutlet UILabel *lable4;
@property (weak, nonatomic) IBOutlet UILabel *lable5;
@property (weak, nonatomic) IBOutlet UILabel *lable6;
@property (weak, nonatomic) IBOutlet UILabel *lable7;

@property(strong,nonatomic) NSString  *access_token;
@property(strong,nonatomic) NSString  *facebook;
@property(strong,nonatomic) NSString  *emailvalid;
@property(strong,nonatomic) NSDictionary  *mydict;

@property(strong,nonatomic) NSString  *str_emaill;




@end

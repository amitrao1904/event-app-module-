//
//  SignupController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "SignupController.h"
#import "CustumCountryCell.h"
@interface SignupController ()
{
    CustumCountryCell *prototypeCell;
    
    
}
@property (strong, nonatomic) IBOutlet UITextField *txt_phone;

@end

@implementation SignupController
@synthesize txt_phone,scrollview,ScrollView,btn_countrycode,tblNew,view1,searchBar,searchdisplaycontroller,lable1,lable2,txt_search,Return_respos,ArrayRestaurant,view_search,Search_logo;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    Search_logo.hidden=false;
    
    lable1.hidden=YES;
    lable2.hidden=YES;
    
    view_search.layer.borderWidth=1;
    view_search.layer.borderColor=[UIColor blackColor].CGColor;
    
    view1.hidden=YES;
    
    UIColor *color = [UIColor whiteColor];
    self.txt_phone.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Mobile No." attributes:@{NSForegroundColorAttributeName: color}];
    
    
    MSSearchArrayTitle=[[NSMutableArray alloc]init];
    ArrayRestaurant =[[NSMutableArray alloc]init];
    array_user=[[NSMutableArray alloc]init];
    array_countrycode=[[NSMutableArray alloc]init];
    array_sortname=[[NSMutableArray alloc]init];
    array_countryname=[[NSMutableArray alloc]init];
    array_id=[[NSMutableArray alloc]init];
//    [array_countrycode addObject:@"AU +61"];
//    [array_countrycode addObject:@"AU +62"];
//    [array_countrycode addObject:@"AU +63"];
//    [array_countrycode addObject:@"AU +64"];
//    [array_countrycode addObject:@"AU +65"];
//    [array_countrycode addObject:@"AU +66"];
//    [array_countrycode addObject:@"AU +67"];
    
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method
-(void)viewWillAppear:(BOOL)animated
{
    [self countrycodelistAPI_Call];

}
-(void) validation
{
    if([self.btn_countrycode.titleLabel.text isEqualToString:@"CODE"])
    {
        lable1.hidden=NO;
        lable1.text=@"Please Select Code.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation1:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        
        
        
        return;
        
    }
    if(self.txt_phone.text.length == 0)
    {
        
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Phone Number cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation2:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        
        
        
        return;
    }
    else
    {
        [self signupAPI_Call];
        
//        PhoneConfirmationController *phoneconfirmation = [self.storyboard instantiateViewControllerWithIdentifier:@"phoneconfirm"];
//        [self.navigationController pushViewController:phoneconfirmation animated:true];

    }
}
-(void)scrollViewScrollingwithAnimation1:(NSTimer *)timer
{
    lable1.hidden=YES;
    
    
    
}
-(void)scrollViewScrollingwithAnimation2:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
    
    
}

-(void)setPickerView
{
    
    // self.currentResponder=textField;
    //  [textField resignFirstResponder];
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone || [UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad)
    {    // The iOS device = iPhone or iPod Touch
        
        
        CGSize iOSDeviceScreenSize = [[UIScreen mainScreen] bounds].size;
        
        if (iOSDeviceScreenSize.height == 480)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-176-44, 320, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-176, 320, 180);
        }
        if (iOSDeviceScreenSize.height == 568)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-176-44, 320, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-176, 320, 180);
        }
        
        if (iOSDeviceScreenSize.height == 667)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-176-44, 375, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-176, 375, 180);
        }
        if (iOSDeviceScreenSize.height == 736)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-176-44, 414, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-176, 414, 180);
        }
        if (iOSDeviceScreenSize.height == 1024)
        {
            toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-176-44, 768, 44);
            datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-176, 768, 180);
        }
        
        
    }else{
        toolbarTargetFrame = CGRectMake(0, self.view.bounds.size.height-176-44, 768, 44);
        datePickerTargetFrame = CGRectMake(0, self.view.bounds.size.height-176, 768, 180);
    }
    
    
    
    darkView1 = [[UIView alloc] initWithFrame:self.view.bounds] ;
    darkView1.alpha = 0;
    darkView1.backgroundColor = [UIColor blackColor];
    darkView1.tag = 9;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(PickerCancel)] ;
    
    [darkView1 addGestureRecognizer:tapGesture];
    [self.view addSubview:darkView1];
    
    pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height+84, 320, 186)] ;
    pickerView.delegate = self;
    pickerView.dataSource = self;
    
    
    pickerView.tag = 10;
    pickerView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:pickerView];
    
    //toolbar for country picker view
    toolBar1 = [[UIToolbar alloc] initWithFrame:CGRectMake(0, self.view.bounds.size.height, 320, 44)] ;
    toolBar1.tag = 11;
    toolBar1.barStyle = UIBarStyleBlackTranslucent;
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil] ;
    
    // UIImage* image3 = [UIImage imageNamed:@"confirm.png"];
    CGRect frameimg = CGRectMake(0, 0, 50, 40);
    
    
    //done button
    UIButton *someButton = [[UIButton alloc] initWithFrame:frameimg];
    
    //[someButton setBackgroundImage:image3 forState:UIControlStateNormal];
    
    [someButton setTitle:@"Done" forState:UIControlStateNormal];
    [someButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [someButton addTarget:self action:@selector(PickerDone)
         forControlEvents:UIControlEventTouchUpInside];
    //[someButton setShowsTouchWhenHighlighted:YES];
    
    UIBarButtonItem *doneButton =[[UIBarButtonItem alloc] initWithCustomView:someButton];
    
    [toolBar1 setItems:[NSArray arrayWithObjects:spacer, doneButton, nil]];
    
    [self.view addSubview:toolBar1];
    
    toolBar1.frame = toolbarTargetFrame;
    pickerView.frame = datePickerTargetFrame;
    
    darkView1.alpha = 0.5;
    toolBar1.alpha = 1;
    pickerView.alpha = 1;
    
    
    
}

#pragma mark - API Method
-(void)countrycodelistAPI_Call
{
    [self.view endEditing:YES];
    
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    
    postParams =  @{
                    
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, COUNTRYCODELIST];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:GET url:loginURl andParameters:postParams forTask:kTaskCountryCode currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         if (success)
         {
//             NSArray *arr=[response valueForKey:@"countries"];
//             
//             array_countryname=[arr valueForKey:@"country_name"];
//             array_sortname=[arr valueForKey:@"sortname"];
//             array_countrycode=[arr valueForKey:@"country_phonecode"];
//             array_id=[arr valueForKey:@"id"];
//             
//             
//             Return_respos=[response valueForKey:@"countries"];
//
//             
//             
//             NSArray *msgarr=[response objectForKey:@"countries"];
//             for (int i =0; i<[msgarr count]; i++)
//             {
//                 NSDictionary *dict=[msgarr objectAtIndex:i];
//                 
//                 ModelClass *obj11=[[ModelClass alloc]init];
//                 obj11.country_name=[dict valueForKey:@"country_name"];
//                 
//                 obj11.country_phonecode=[dict valueForKey:@"country_phonecode"];
//                 obj11.idd=[dict valueForKey:@"id"];
//                 obj11.sortname=[dict valueForKey:@"sortname"];
//        
//                 [array_user addObject:obj11];
//                 
//                 
//                 
//             }
//            
//             
//             [tblNew reloadData];
             
            ArrayRestaurant= [response valueForKey:@"countries"];
             
             Return_respos = ArrayRestaurant;
             if([Return_respos count]>0)
             {
                 NSLog(@"data of array %@",Return_respos);
                 [tblNew reloadData];
                 
             }
             
             
             
             
         } else
         {
             @try
             {
                 [Util showAlertMessage:@"invalid" withTitle:@"Alert"];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }
     }];
    
}

- (void)signupAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    def=[NSUserDefaults standardUserDefaults];
    NSDictionary *postParams;
    
    
    postParams =  @{
                    @"mobile"      : txt_phone.text,
                    @"country_id"  : [NSString stringWithFormat:@"%@",country_id],
                    @"device_id"   : [def valueForKey:@"uniqueIdentifierID"],
                    
                    };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, MOBILEREG];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskRegMobile currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         NSString *type=[[[response valueForKey:@"data"] valueForKey:@"otp"] valueForKey:@"type"];
         
         
         if ([type isEqualToString:@"error"])
         {
             
             [Util showAlertMessage:message withTitle:@"Alert"];
             return;
             
         }
         
         if (a==1)
         {
             
             [Util showAlertMessage:message withTitle:@"Alert"];
             
            PhoneConfirmationController *phoneconfirmation = [self.storyboard instantiateViewControllerWithIdentifier:@"phoneconfirm"];
             
             phoneconfirmation.phonenumber=[[[response valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"format_mobile"];
             
             phoneconfirmation.access_token=[[[response valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"auth_key"];
             
            [self.navigationController pushViewController:phoneconfirmation animated:true];
             
         }
         
         else
         {
             @try
             {
                 //[Util showAlertMessage:message withTitle:@"Alert"];
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 lable1.text=[NSString stringWithFormat:@"%@",message];
                 
                 
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
                 
                 
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }

         
         
     }];
}
- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}


#pragma mark - Action Method
- (IBAction)Searchh:(id)sender
{
    Search_logo.hidden=true;
    
    Return_respos=[[NSMutableArray alloc]init];
    
    static int i;
    for (i=0;i<ArrayRestaurant.count;i++)
        
    {
        NSDictionary *dict = [ArrayRestaurant objectAtIndex:i];
        NSString *target=[dict objectForKey:@"country_name"];
        
        
        
        if([target rangeOfString:txt_search.text options:NSCaseInsensitiveSearch].location ==NSNotFound)
        {
            NSLog(@"NOT SuccessFull");
            
        }else
        {
            
            [Return_respos addObject:dict];
            NSLog(@"  SuccessFull");
        }
    }
    if([txt_search.text isEqualToString:@""])
        
    {
        Return_respos=ArrayRestaurant;
        Search_logo.hidden=false;
    }
    
    [tblNew reloadData ];
    
    
}
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btn_actionEmail:(id)sender
{
   // SignupEmailController *signupemail = [self.storyboard instantiateViewControllerWithIdentifier:@"signupemail"];
   // [self.navigationController pushViewController:signupemail animated:true];
    
    
        SignupEmailController *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"signupemail"];
        CATransition *transition = [CATransition animation];
        transition.duration = 0.3;
        transition.type = kCATransitionFade;
        //transition.subtype = kCATransitionFromTop;
    
        [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
        [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)btn_nextAction:(id)sender {
    [self validation];
    
//    PhoneConfirmationController *phoneconfirmation = [self.storyboard instantiateViewControllerWithIdentifier:@"phoneconfirm"];
//    [self.navigationController pushViewController:phoneconfirmation animated:true];
    
}
- (IBAction)countrycode_Action:(id)sender
{
    
//    countryFlag = true;
//    
//    [self setPickerView];
    
   // [self countrycodelistAPI_Call];
    
    view1.hidden=NO;
    
}



-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if(textField == txt_phone)
    {
        NSUInteger newLength = [textField.text length] + [string length] - range.length;
        return (newLength > 10) ? NO : YES;
    }
    
    
    
    
    return true;
}



-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    
        return [array_countryname count];
    
   
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
   
        return [array_countryname objectAtIndex:row];
    
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
   
        NSString *str_dd =[array_countryname objectAtIndex:row];
        
   
}

-(void)PickerDone
{
    int row = [pickerView selectedRowInComponent:0];
    //NSString *obj6;
    
   
        NSString *str_sort=[array_sortname objectAtIndex:row];
    
        str_code=[array_countrycode objectAtIndex:row];
    
    
        country_id=[array_id objectAtIndex:row];
    
    
    NSString *mycode=[NSString stringWithFormat:@"%@ +%@",str_sort,str_code];
    
    
        // COUNTRYCODE =[countryCODE objectAtIndex:row];
        
        [btn_countrycode setTitle:mycode forState:UIControlStateNormal];
        
        
    
    
    CGAffineTransform transfrom = CGAffineTransformMakeTranslation(0, 200);
    
    CGAffineTransform transfrom1 = CGAffineTransformMakeTranslation(0, 260);
    
    pickerView.transform = transfrom;
    pickerView.alpha = pickerView.alpha * (-1) + 1;
    
    toolBar1.transform = transfrom1;
    toolBar1.alpha = toolBar1.alpha * (-1) + 1;
    
    [UIView commitAnimations];
    //[self scrollContent];
    darkView1.hidden=YES;
    
}


-(void) PickerMethod
{
    // [self HideKeyBoard];
    
    toolBar1.alpha=1;
    pickerView.alpha=1;
    
    darkView1.hidden=NO;
    pickerView.hidden=NO;
    toolBar1.hidden=NO;
    
    CGAffineTransform transfrom = CGAffineTransformMakeTranslation(0, 0);
    
    toolBar1.transform = transfrom;
    toolBar1.alpha = toolBar1.alpha * (1) + 1;
    
    pickerView.transform = transfrom;
    pickerView.alpha = pickerView.alpha * (1) ;
}
-(void)PickerCancel
{
    ScrollView.contentSize = CGSizeMake(320,700);//850
    
    [ScrollView setScrollEnabled:YES];
    CGAffineTransform transfrom = CGAffineTransformMakeTranslation(0, 200);
    
    CGAffineTransform transfrom1 = CGAffineTransformMakeTranslation(0, 260);
    
    pickerView.transform = transfrom;
    pickerView.alpha = pickerView.alpha * (-1) + 1;
    
    toolBar1.transform = transfrom1;
    toolBar1.alpha = toolBar1.alpha * (-1) + 1;
    
    [UIView commitAnimations];
    
    // [self scrollContent];
    
    
    darkView1.hidden=YES;
    
}
-(void)scrollContent{
    //ScrollView.contentSize = CGSizeMake(320,700);
    ScrollView.scrollEnabled = YES;
    ScrollView.delegate = self;
    [ScrollView setShowsVerticalScrollIndicator:YES];
    [ScrollView setShowsVerticalScrollIndicator:NO];
    [ScrollView  setContentSize:CGSizeMake(ScrollView.frame.size.width, ScrollView.frame.size.height)];
}
- (void)handleSingleTap:(UITapGestureRecognizer *) sender
{
    [self.view endEditing:YES];
}

- (void)pickerDoneButtonPressed {
    [self.view endEditing:YES];
    
}
#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
        return [Return_respos count];
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
      prototypeCell = (CustumCountryCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([CustumCountryCell class])];
    
//     ModelClass *obj11=[array_user objectAtIndex:indexPath.row];
//
//    prototypeCell.lable1.text=obj11.country_name;
//    prototypeCell.lable2.text=[NSString stringWithFormat:@"+ %@",obj11.country_phonecode];
    
    NSDictionary *dict = [Return_respos objectAtIndex:indexPath.row];
    
    //prototypeCell.lable1.text=[dict valueForKey:@"country_name"];
    
    
    NSString *strName = [NSString stringWithFormat:@"%@",[dict valueForKey:@"country_name"]];
    

    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:strName];
    
    NSRange range = [strName rangeOfString:txt_search.text];
    [attString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:0.2 green:0.6 blue:1 alpha:1] range:range];
    prototypeCell.lable1.attributedText = attString;
    
    
    prototypeCell.lable2.text=[NSString stringWithFormat:@"+ %@",[dict valueForKey:@"country_phonecode"]];
    
    
    
        return prototypeCell;
        
 }
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
//    ModelClass *obj11=[array_user objectAtIndex:indexPath.row];
//    
//    NSString *str_sort=obj11.sortname;
//    
//    str_code=obj11.country_phonecode;
//    
//    
//    country_id=obj11.idd;
//    
//    
//    NSString *mycode=[NSString stringWithFormat:@"%@ +%@",str_sort,str_code];
//    
//    
//    [btn_countrycode setTitle:mycode forState:UIControlStateNormal];
//    
//    view1.hidden=YES;
    
    NSDictionary *dict = [Return_respos objectAtIndex:indexPath.row];
    
    NSString *str_sort=[dict valueForKey:@"sortname"];
    str_code=[dict valueForKey:@"country_phonecode"];
    country_id=[dict valueForKey:@"id"];
    
    NSString *mycode=[NSString stringWithFormat:@"%@ +%@",str_sort,str_code];
    
    [btn_countrycode setTitle:mycode forState:UIControlStateNormal];
    
    view1.hidden=YES;
    
}


#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

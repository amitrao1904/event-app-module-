//
//  RegisterController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "RegisterController.h"

@interface RegisterController ()

@end

@implementation RegisterController
static NSString *const kClientSecret =@"c465d6486a893109b40a128ee7f54fe1";
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method



#pragma mark - API Method
// User Facebook Login
- (void)FBLoginAPI_CallWithParam:(id)param
{
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *fbLoginURl;
    
    def=[NSUserDefaults standardUserDefaults];

    
    
    NSDictionary *postParams =  @{
                                  @"User[source_id]"          : [param valueForKey:@"id"],
                                  @"User[device_id]"          : [def valueForKey:@"uniqueIdentifierID"],
                                  @"User[email]"               : [param valueForKey:@"email"],
                                  @"User[source]"            : @"facebook",
                                  
                                  };
    
    
    
    
    fbLoginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, WEB_URL_UserFbLogin];
   
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:fbLoginURl andParameters:postParams forTask:KTaskFbLogin currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
             //  [Util showAlertMessage:message withTitle:@"Alert"];
             
             
             
             
             
             [Util showAlertMessage:message withTitle:@"Alert"];
             
             
             if ([message isEqualToString:@"Successfully registered"])
             {
  
                 
                 RegistrationVCController *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
                 CATransition *transition = [CATransition animation];
                 transition.duration = 0.3;
                 transition.type = kCATransitionFade;
                 //transition.subtype = kCATransitionFromTop;
                 
                 addinvController.mydict=[response valueForKey:@"data"];
                 
                 
                 addinvController.facebook=@"facebook";
                 
                 [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
                 [self.navigationController pushViewController:addinvController animated:NO];
             }
             if ([message isEqualToString:@"Already registered"])
             {
                 
                 
                 LoginController *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"login"];
                 CATransition *transition = [CATransition animation];
                 transition.duration = 0.3;
                 transition.type = kCATransitionFade;
                 //transition.subtype = kCATransitionFromTop;
                [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
                 [self.navigationController pushViewController:addinvController animated:NO];
             }
             
         }
         
         else
         {
             @try
             {
                 
                 
                  [Util showAlertMessage:message withTitle:@"Alert"];
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }

        
     }];
    
}


#pragma mark - Action Method

- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)signup_action:(id)sender {
    SignupController *signup = [self.storyboard instantiateViewControllerWithIdentifier:@"signup"];
    [self.navigationController pushViewController:signup animated:true];

}
- (IBAction)facebook_Action:(id)sender
{
//    RegistrationVCController *signup = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationvc"];
//    [self.navigationController pushViewController:signup animated:true];
    
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    
    [login logInWithReadPermissions: @[@"public_profile", @"email"]
                 fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
                     if (error)
                         DLog(@"Process error");
                     else if (result.isCancelled)
                         DLog(@"Cancelled");
                     else
                     {
                         if (result.token) {
                             [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"email,name,first_name,last_name,birthday,gender"}]
                              startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                                  if (!error)
                                  {
                                      //NSString *gender = [user objectForKey:@"gender"];
                                      fbAccessToken = [FBSDKAccessToken currentAccessToken].tokenString;
                                      
                                      NSLog(@"...%@",result);
                                      
                                      pictureURL = [NSURL URLWithString:[NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=large&return_ssl_resources=1", [result valueForKey:@"id"]]];
                                      //
                                      
                                      profileurl = [NSURL URLWithString:[NSString stringWithFormat:@"www.facebook.com/%@",[result valueForKey:@"id"]]];
                                      
                                      
                                      
                                      
                                      //[[UIApplication sharedApplication] openURL:url];
                                      
                                      // <* Register User after accessing user detail from facebook
                                      [self FBLoginAPI_CallWithParam:result];
                                  }
                              }];
                         }
                     }
                 }];
    
}
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
#pragma mark - Memory CleanUp



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

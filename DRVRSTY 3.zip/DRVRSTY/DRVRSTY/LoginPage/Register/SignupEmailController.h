//
//  SignupEmailController.h
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EmailConfirmationController.h"
#import "SignupController.h"

@interface SignupEmailController : UIViewController
{

    NSUserDefaults *def;
}
@property (weak, nonatomic) IBOutlet UILabel *lable1;
@property (weak, nonatomic) IBOutlet UILabel *lable2;
@end

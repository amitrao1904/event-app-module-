//
//  SignupEmailController.m
//  DRVRSTY
//
//  Created by Shiv Pareek on 04/04/17.
//  Copyright © 2017 Rahul Mishra. All rights reserved.
//

#import "SignupEmailController.h"

@interface SignupEmailController ()
@property (weak, nonatomic) IBOutlet UITextField *txt_token;

@end

@implementation SignupEmailController
@synthesize txt_token,lable1,lable2;
- (void)viewDidLoad {
    [super viewDidLoad];
    lable1.hidden=YES;
    lable2.hidden=YES;
    UIColor *color = [UIColor darkGrayColor];
    self.txt_token.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"John@Citizen.com" attributes:@{NSForegroundColorAttributeName: color}];
    // Do any additional setup after loading the view.
}

#pragma mark - Custom Method

-(void) validation{
    if(self.txt_token.text.length == 0)
    {
        
        
        lable1.hidden=NO;
        lable2.hidden=NO;
        lable1.text=@"Email cannot be blank.";
        [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation11:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
        return;

    }
    else
    {
//        EmailConfirmationController *emailconfirmation = [self.storyboard instantiateViewControllerWithIdentifier:@"emailconfirm"];
//        [self.navigationController pushViewController:emailconfirmation animated:true];
        [self signupemailAPI_Call];
    }
}
-(void)scrollViewScrollingwithAnimation11:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}
#pragma mark - API Method
- (void)signupemailAPI_Call
{
    [self.view endEditing:YES];
    //*>    Check network status if available then proceed otherwise show alert.
    if (![appDelegate() bNetworkAvailable])
    {
        [Util showNetWorkAlert];
        return;
    }
    
    NSString *loginURl;
    
    NSDictionary *postParams;
    
    def=[NSUserDefaults standardUserDefaults];
    
    postParams =  @{
                    
                    @"TmpUsers[email]"          : txt_token.text,
                    @"TmpUsers[device_id]"      : [def valueForKey:@"uniqueIdentifierID"],
                    
                   };
    
    
    loginURl = [NSString stringWithFormat:@"%@%@", BASE_URL, REGISTRATION];
    
    [serviceManager apiCallUsingOperationManagerHTTPMethod:POST url:loginURl andParameters:postParams forTask:kTaskRegEmail currentView:self.view accessToken:NO completionHandler:^(id response, NSError *error, TaskType task, BOOL success)
     {
         
         
         
         int a=[[response valueForKey:@"success"] intValue];
         
         NSString *message=[response valueForKey:@"message"];
         
         
         if (a==1)
         {
             
            [Util showAlertMessage:message withTitle:@"Alert"];
             
            EmailConfirmationController *emailconfirmation = [self.storyboard instantiateViewControllerWithIdentifier:@"emailconfirm"];
            emailconfirmation.str_email=txt_token.text;
             emailconfirmation.access_token=[[response valueForKey:@"data"] valueForKey:@"auth_key"];
            [self.navigationController pushViewController:emailconfirmation animated:true];
             
         }
         
         else
         {
             @try
             {
                // [Util showAlertMessage:message withTitle:@"Alert"];
                 
                 lable1.hidden=NO;
                 lable2.hidden=NO;
                 
                 lable1.text=[response valueForKey:@"message"];
                 
            
                 [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(scrollViewScrollingwithAnimation:) userInfo:[NSString stringWithFormat:@"%d", 0] repeats:NO];
                 
             }
             @catch (NSException *exception)
             {
                 return;
             }
             @finally { }
         }

         

     }];
}

- (void)scrollViewScrollingwithAnimation:(NSTimer *)timer
{
    lable1.hidden=YES;
    lable2.hidden=YES;
    
}

#pragma mark - Action Method
- (IBAction)hidekey:(id)sender
{
    [sender resignFirstResponder];
}
- (IBAction)btn_back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btn_nextAction:(id)sender {
    
    [self validation];
    
//    EmailConfirmationController *emailconfirmation = [self.storyboard instantiateViewControllerWithIdentifier:@"emailconfirm"];
//    [self.navigationController pushViewController:emailconfirmation animated:true];
}
- (IBAction)btn_phoneAction:(id)sender {
 //   SignupController *signupcontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"signup"];
   // [self.navigationController pushViewController:signupcontroller animated:true];
    
    
    SignupController *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"signup"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

#pragma mark - Memory CleanUp

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  DRVCustomMechanicCell.h
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVCustomMechanicCell : UITableViewCell
@property(strong,nonatomic)IBOutlet UITextField *txt_firstname;
@property(strong,nonatomic)IBOutlet UITextField *txt_lastname;
@property(strong,nonatomic)IBOutlet UITextField *txt_phoneno;
@property(strong,nonatomic)IBOutlet UITextField *txt_email;


@property(strong,nonatomic)IBOutlet UITextField *txt_businessname;
@property(strong,nonatomic)IBOutlet UITextField *txt_businessphone;
@property(strong,nonatomic)IBOutlet UITextField *txt_businessemail;
@property(strong,nonatomic)IBOutlet UITextField *txt_website;
@property(strong,nonatomic)IBOutlet UITextField *txt_country;
@property(strong,nonatomic)IBOutlet UITextField *txt_address;
@property(strong,nonatomic)IBOutlet UITextField *txt_city;
@property(strong,nonatomic)IBOutlet UITextField *txt_state;
@property(strong,nonatomic)IBOutlet UITextField *txt_postcode;

@property(strong,nonatomic)IBOutlet UIButton *btn_next;
@end

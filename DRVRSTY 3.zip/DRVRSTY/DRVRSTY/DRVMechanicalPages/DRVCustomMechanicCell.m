//
//  DRVCustomMechanicCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCustomMechanicCell.h"

@implementation DRVCustomMechanicCell
@synthesize txt_city,txt_email,txt_state,txt_address,txt_country,txt_phoneno,txt_website,txt_lastname,txt_postcode,txt_firstname,txt_businessname,txt_businessemail,txt_businessphone,btn_next;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

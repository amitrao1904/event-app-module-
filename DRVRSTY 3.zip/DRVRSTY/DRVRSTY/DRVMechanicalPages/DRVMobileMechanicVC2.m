//
//  DRVMobileMechanicVC2.m
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVMobileMechanicVC2.h"
#import "DRVCustomMechanicCell.h"
@interface DRVMobileMechanicVC2 ()

@end

@implementation DRVMobileMechanicVC2
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)chat_Action:(id)sender
{
    DRVInboxVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVInboxVC"];
    [self.navigationController pushViewController:registercontroller animated:true];
}

#pragma mark - TableviewDelegate Method

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    
    return 1;
    
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        return 699;
}

- (void)tableView: (UITableView*)tableView willDisplayCell: (UITableViewCell*)cell forRowAtIndexPath: (NSIndexPath*)indexPath
{
    cell.backgroundColor = [UIColor blackColor];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"Cell";
    
    DRVCustomMechanicCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    //cell.contentView.backgroundColor = [UIColor colorWithRed:0.627 green:0.725 blue:0.761 alpha:1];
    
    
    
    if (cell == nil)
    {

    }
    UIColor *color = [UIColor whiteColor];
    cell.txt_firstname.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"First Name" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_lastname.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Last Name" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_phoneno.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Phone Number" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_email.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Email" attributes:@{NSForegroundColorAttributeName: color}];
    
    
    cell.txt_businessname.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Business Name" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_businessphone.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Business Phone" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_businessemail.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Business Email" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_website.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Website" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_country.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Country" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_address.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Address" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_city.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"City" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_state.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"State" attributes:@{NSForegroundColorAttributeName: color}];
    cell.txt_postcode.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Postcode" attributes:@{NSForegroundColorAttributeName: color}];
    
    
     [cell.btn_next addTarget:self action:@selector(nextpress:) forControlEvents:UIControlEventTouchUpInside];
    
    
    return cell;
}
- (void)nextpress:(UIButton*)sender
{
    DRVMobileMechanicVC3 *login = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC3"];
    [self.navigationController pushViewController:login animated:true];
}

#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  Util.h
//  KrewCal
//
//  Created by Deepak Pandey on 5/26/15.
//  Copyright (c) 2015 Neuron Solutions Inc. All rights reserved.
//

enum CustomAlertViewMode : NSUInteger {
    
    CustomAlertViewModeDefault              = 0,
    CustomAlertViewModeOnlyConfirm          = 1,
    CustomAlertViewModeConfirmDestructive   = 2,
    CustomAlertViewModeDefaultDestructive   = 3,
    CustomAlertViewModeWithoutButton        = 4
};

#import <Foundation/Foundation.h>

@interface Util : NSObject


+ (BOOL)isValidUrl: (NSString *)url;
+ (BOOL)isValidString:(NSString *)string;

+ (BOOL) NSStringIsValidEmail:(NSString *)checkString;
+ (BOOL) NSStringIsValidName:(NSString *)checkString;
+ (NSString*)getValidString:(NSString *)string;
+ (NSString *)getUrlStringWithHttpVerb:(NSString *)url;
+ (void)showAlertMessage:(NSString *)message withTitle:(NSString *)title;
+ (void)showNetWorkAlert;

//** Date Utility Methods
+ (NSString *)getStringFromGMTDate:(NSDate *)date withFormat:(NSString *)strFormat;
+ (NSString *)getStringFromDate:(NSDate *)date withFormat:(NSString *)strFormat;
+ (NSDate *)getDateFromString:(NSString *)strDate withFormat:(NSString *)strFormat;
+ (NSDate *)getUTCFormateDate:(double)timeInSeconds;
+ (NSString *)getAgeFromBirthday:(NSString *)strBirthdate;
+ (NSDate *)dateAtBeginningOfYesterdayForDate:(NSDate *)inputDate;
+ (NSDate *)dateAtBeginningOfDayForDate:(NSDate *)inputDate;
+ (NSString *)getTimeFromMinuteString:(NSString *)strMinute;

+ (BOOL)isSameDayWithDate1:(NSDate*)date1 date2:(NSDate*)date2;
+ (BOOL)date1:(NSDate *)date1 isYesterdayFromDate2:(NSDate *)date2;

+ (NSDate *)endOfDay:(NSDate *)date;
+ (NSDate *)beginningOfDay:(NSDate *)date;

extern id ObjectOrBlank(id object);

+ (NSString *)appVersion;
+ (NSString *)build;

+ (NSString *)extractComponentsInString:(NSDate *)date;

+ (NSString *)stringWithoutNilOrNull :(NSString *)checkString;

+ (NSString*)base64forData:(NSData*) theData;
+ (NSString*)convertNSDateIntoNSString;
+ (NSData*)CompressImageData:(UIImage*)croppedImage imageDataMinCheckLenght:(float)lenght;
//+ (void)setRoundedImage:(id)roundedView toDiameter:(float)newSize;

//Resize image from a given image
+ (UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize;
+ (UIImage *)resizeImage:(UIImage*)image newSize:(CGSize)newSize;
+ (void)setViewGradient:(UIView *)view;
+ (NSString *)getCountryTimezone;
+ (NSDateFormatter *)dateFormatter:(NSString*)strType;
+ (UIButton*)makeBreathingAnimationButton:(UIButton*)btn;
+ (void)addBorderToImageView : (UIImageView *)imgView andRadius:(float)radius;

+ (void)addTableDashSeparatorWithLayer : (CALayer *)viewLayer andWidth :(int)width andHeight :(int)height;
@end

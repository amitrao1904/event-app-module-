//
//  Util.m
//  KrewCal
//
//  Created by Deepak Pandey on 5/26/15.
//  Copyright (c) 2015 Neuron Solutions Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Util.h"

@implementation CALayer (Additions)

- (void)setBorderColorFromUIColor:(UIColor *)color
{
    self.borderColor = color.CGColor;
}

@end

@implementation Util

#pragma mark - Validation

+ (BOOL)isValidUrl:(NSString *)url {
    
    /*NSString *urlRegEx =
     
     @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
     
     NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
     
     return [urlTest evaluateWithObject:url];*/
    
    NSURL *candidateURL = [NSURL URLWithString:url];
    
    // WARNING > "test" is an URL according to RFCs, being just a path
    
    // so you still should check scheme and all other NSURL attributes you need
    if (candidateURL && candidateURL.scheme && candidateURL.host) {
        
        // candidate is a well-formed url with:
        
        //  - a scheme (like http://)
        
        //  - a host (like stackoverflow.com)
        
        return YES;
    }
    return NO;
}

+ (NSString *)getUrlStringWithHttpVerb:(NSString *)url {
    
    [self getValidString:url];
    if (!([url hasPrefix:@"http://"] || [url hasPrefix:@"https://"])) {
        
        url = [NSString stringWithFormat:@"http://%@",url];
    }
    return url;
}

+ (BOOL)isValidString:(NSString *)string

{
    if ([string isKindOfClass:[NSString class]] &&  ([string isKindOfClass:[NSNull class]] || string.length == 0 || [string isEqualToString:@"null"] || [string isEqualToString:@"<null>"] || [string isEqualToString:@"(null)"]))
        return NO;
    return YES;
}


+ (BOOL)NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}


+ (BOOL)NSStringIsValidName:(NSString *)checkString
{
    NSString *nameRegex = @"[A-Za-z]+";
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return [nameTest evaluateWithObject:checkString];
}

+ (NSString*)getValidString:(NSString *)string
{
    if ([Util isValidString:string] && string.length > 0) {
        string = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    } else {
        string = @"";
    }
    return string;
}


#pragma mark - Show Alert 

// Show an alert message
+ (void)showAlertMessage:(NSString *)message withTitle:(NSString *)title
{
    [[[UIAlertView alloc] initWithTitle:title
                                message:message
                               delegate:nil
                      cancelButtonTitle:@"OK"
                      otherButtonTitles:nil] show];
}

// Show an Network alert message

+ (void)showNetWorkAlert {
    
    UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"No Network Connection" message:@"Please check your connection and try again." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    
    [alert show];
    
}

#pragma  Date Utility Methods

+ (NSString *)getStringFromGMTDate:(NSDate *)date withFormat:(NSString *)strFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:strFormat];
    
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormat setTimeZone:gmt];
    
    NSString *strDate = [dateFormat stringFromDate:date];
    
    return strDate;
}

+ (NSString *)getStringFromDate:(NSDate *)date withFormat:(NSString *)strFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:strFormat];
    
    NSString *strDate = [dateFormat stringFromDate:date];
    
    return strDate;
}

+ (NSString *)getTimeFromMinuteString:(NSString *)strMinute
{
    NSDate *now = [NSDate date];
    NSDate *newDate = [now dateByAddingTimeInterval:[strMinute intValue] * 60];
    
    NSDateFormatter *timeFormatter = [[NSDateFormatter alloc]init];
    timeFormatter.dateFormat = @"HH:mm:ss";
    
    return [timeFormatter stringFromDate: newDate];
}

+ (NSDate *)getDateFromString:(NSString *)strDate withFormat:(NSString *)strFormat
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:strFormat];
    
    NSDate *date = [dateFormat dateFromString:strDate];
    
    return date;
}

+ (NSDate *)getUTCFormateDate:(double)timeInSeconds
{
    NSTimeInterval mytime = timeInSeconds;
    DLog(@"mytime:%f",mytime);
    NSDate *localDate = [NSDate dateWithTimeIntervalSince1970:mytime];
    DLog(@"localDate:%@",localDate);
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [dateFormatter setTimeZone:timeZone];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:localDate];
    //return dateString;
    return [dateFormatter dateFromString:dateString];
}



+ (NSString *)getAgeFromBirthday:(NSString *)strBirthdate
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    NSDate *dateBirthdate = [dateFormatter dateFromString:strBirthdate];
    NSDate* now = [NSDate date];
    NSDateComponents* ageComponents = [[NSCalendar currentCalendar]
                                       components:NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay
                                       fromDate:dateBirthdate
                                       toDate:now
                                       options:0];
    NSInteger age       = [ageComponents year];
    NSString *strAge    = [NSString stringWithFormat:@"%li", (long)age];
    
    return strAge;
}

+ (NSDate *)dateAtBeginningOfDayForDate:(NSDate *)inputDate
{
    // Use the user's current calendar and time zone
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    //NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    //[calendar setTimeZone:gmt];
    
    // Selectively convert the date components (year, month, day) of the input date
    NSDateComponents *dateComps = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay fromDate:inputDate];
    
    // Set the time components manually
    [dateComps setDay:dateComps.day];
    [dateComps setHour:0];
    [dateComps setMinute:0];
    [dateComps setSecond:0];
    
    // Convert back
    NSDate *beginningOfDay = [calendar dateFromComponents:dateComps];
    return beginningOfDay;
}

+ (NSDate *)dateAtBeginningOfYesterdayForDate:(NSDate *)inputDate
{
    // Use the user's current calendar and time zone
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    //NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    //[calendar setTimeZone:gmt];
    
    // Selectively convert the date components (year, month, day) of the input date
    NSDateComponents *dateComps = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay fromDate:inputDate];
    
    // Set the time components manually
    [dateComps setDay:dateComps.day - 1];
    [dateComps setHour:0];
    [dateComps setMinute:0];
    [dateComps setSecond:0];
    
    // Convert back
    NSDate *beginningOfDay = [calendar dateFromComponents:dateComps];
    return beginningOfDay;
}

+ (NSDate *)endOfDay:(NSDate *)date
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSDateComponents *components = [NSDateComponents new];
    components.day = 1;
    
    NSDate *theDate = [calendar dateByAddingComponents:components toDate:[self beginningOfDay:date] options:0];
    
    theDate = [theDate dateByAddingTimeInterval:-1];
    
    return theDate;
}

+ (NSDate *)beginningOfDay:(NSDate *)date
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay;
    NSDateComponents *comp = [calendar components:unitFlags fromDate:date];
    
    return [calendar dateFromComponents:comp];
}

+ (BOOL)isSameDayWithDate1:(NSDate *)date1 date2:(NSDate *)date2
{
    NSCalendar *calendar        = [NSCalendar currentCalendar];
    
    unsigned unitFlags          = NSCalendarUnitDay;
    NSDateComponents *comp1     = [calendar components:unitFlags fromDate:date1];
    NSDateComponents *comp2     = [calendar components:unitFlags fromDate:date2];
    
    return [comp1 day] == [comp2 day];
}

+ (BOOL)date1:(NSDate *)date1 isYesterdayFromDate2:(NSDate *)date2
{
    NSCalendar *calendar        = [NSCalendar currentCalendar];
    
    unsigned unitFlags          = NSCalendarUnitDay;
    NSDateComponents *comp1     = [calendar components:unitFlags fromDate:date1];
    NSDateComponents *comp2     = [calendar components:unitFlags fromDate:date2];
    
    return [comp1 day] + 1 == [comp2 day];
}

//Method for passing null values when intented values are not available.
extern id ObjectOrBlank(id object)
{
    //return object ?: [NSNull null];
    return object ?: @"";

}

//Convert NSDate into NSString (With different components)
+ (NSString *)extractComponentsInString:(NSDate *)date
{
    NSCalendar *gregorianCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    // Extract date components into components
    NSDateComponents *components = [gregorianCalendar components:NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay fromDate:date];
    NSInteger year = [components year];
    NSInteger month = [components month];
    NSInteger day = [components day];
    
    NSString *dateInString = [NSString stringWithFormat:@"%ld-%ld-%ld",(long)year,(long)month,(long)day];
    return dateInString;
}

//Convert NSDate into NSString (With different components)
+ (NSString *)extractTimeComponentsInString:(NSDate *)date
{
    NSCalendar *gregorianCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    // Extract date components into components
    NSDateComponents *components = [gregorianCalendar components:NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay fromDate:date];
    NSInteger year = [components year];
    NSInteger month = [components month];
    NSInteger day = [components day];
    
    NSString *dateInString = [NSString stringWithFormat:@"%ld-%ld-%ld",(long)year,(long)month,(long)day];
    return dateInString;
}

+ (NSString *) appVersion
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey: @"CFBundleShortVersionString"];
}

+ (NSString *) build
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey: (NSString *)kCFBundleVersionKey];
}

//Test methods
+ (NSString *)stringWithoutNilOrNull :(NSString *)checkString
{
       if (!checkString || [checkString isKindOfClass:[NSNull class]])
        {
            return checkString;
        }
    //return (!checkString || [checkString isKindOfClass:[NSNull class]]) ? checkString : @"";
    return 0;
}
+ (UIImage*)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize;
{
    NSData *imageData = UIImagePNGRepresentation(image);
    //DLog(@"Image size in MB:%lu",imageData.length/1024);
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    imageData = UIImagePNGRepresentation(newImage);
    //DLog(@"After Compression: Image size in MB:%lu",imageData.length/1024);
    return newImage;
}

+ (UIImage *)resizeImage:(UIImage*)image newSize:(CGSize)newSize
{
    CGRect newRect = CGRectIntegral(CGRectMake(0, 0, newSize.width, newSize.height));
    CGImageRef imageRef = image.CGImage;
    
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // Set the quality level to use when rescaling
    CGContextSetInterpolationQuality(context,kCGInterpolationHigh);
    
    
    CGAffineTransform flipVertical = CGAffineTransformMake(1, 0, 0, -1, 0, newSize.height);
    
    CGContextConcatCTM(context, flipVertical);
    // Draw into the context; this scales the image
    CGContextDrawImage(context, newRect, imageRef);
    
    // Get the resized image from the context and a UIImage
    CGImageRef newImageRef = CGBitmapContextCreateImage(context);
    UIImage *newImage = [UIImage imageWithCGImage:newImageRef];
    
    CGImageRelease(newImageRef);
    UIGraphicsEndImageContext();
    
    return newImage;
}

+ (NSString *)getCountryTimezone
{
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    return [timeZone name];
}
#pragma mark - Base64 conversion for image
+ (NSString*)base64forData:(NSData*) theData {
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}

#pragma mark - Image compression
+ (NSData*)CompressImageData:(UIImage*)croppedImage imageDataMinCheckLenght:(float)lenght
{
    //Compress the image
    CGFloat compression = 0.9f;
    CGFloat maxCompression = 0.1f;
    
    NSData *imageData = UIImageJPEGRepresentation(croppedImage, compression);
    
    NSData *data1 = UIImagePNGRepresentation(croppedImage);
    DLog(@"Real Photo galary image from size in MB :%.2f",(float)data1.length/1024.0f/1024.0f);
    DLog(@"imagedata length : %lu",(unsigned long)imageData.length);
    //eg.lenght - 400000
    while ([imageData length] > lenght && compression > maxCompression)
    {
        compression -= 0.10;
        imageData = UIImageJPEGRepresentation(croppedImage, compression);
              //  DLog(@"Compress : %lu",(unsigned long)imageData.length);
               // DLog(@"Compress Photo galary image from size in MB :%.2f",(float)imageData.length/1024.0f/1024.0f);
    }
    return imageData;
}
//************** Convert NSString into NSDate ********//

+ (NSString*)convertNSDateIntoNSString
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [dateFormatter setDateFormat:@"yyyy-MM-ddHH:mm:ss"];
    NSString *date = [dateFormatter stringFromDate: [NSDate date]];
    
    return date;
}

/**
 **    Get Date formatter.
 **/
+ (NSDateFormatter *)dateFormatter:(NSString*)strType
{
    static NSDateFormatter *dateFormatter;
    
    if(!dateFormatter)
    {
        dateFormatter = [NSDateFormatter new];
    }
    dateFormatter.dateFormat = strType;
    return dateFormatter;
}
//************** Performing breathing animation on UIButton ********//

+ (UIButton*)makeBreathingAnimationButton:(UIButton*)btn
{
    CABasicAnimation *transformAnimation = [CABasicAnimation animationWithKeyPath:@"transform"];
    transformAnimation.duration = 0.2;
    transformAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    transformAnimation.removedOnCompletion = YES;
    transformAnimation.fillMode = kCAFillRuleEvenOdd;
    
    CATransform3D xform = CATransform3DIdentity;
    xform = CATransform3DScale(xform, 1.2, 1.2, 1.0);
    //xform = CATransform3DTranslate(xform, 60, -60, 0);
    transformAnimation.toValue = [NSValue valueWithCATransform3D:xform];
    transformAnimation.repeatCount = 0;
    transformAnimation.autoreverses = YES;
    [btn.layer addAnimation:transformAnimation forKey:@"transformAnimation"];
    return btn;
}

// Add Radius corner with border
+ (void)addBorderToImageView : (UIImageView *)imgView andRadius:(float)radius
{
    imgView.layer.cornerRadius         = radius;
    imgView.clipsToBounds              = YES;
    imgView.layer.borderWidth          = 1.0f;
    imgView.layer.borderColor          = [UIColor whiteColor].CGColor;
    imgView.layer.rasterizationScale   = [UIScreen mainScreen].scale;
    imgView.layer.shouldRasterize      = YES;
}

+ (void)addTableDashSeparatorWithLayer : (CALayer *)viewLayer andWidth :(int)width andHeight :(int)height
{
    CAShapeLayer *shapelayer = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPath];
    //draw a line
    [path moveToPoint:CGPointMake(0.0, height)]; //add yourStartPoint here
    [path addLineToPoint:CGPointMake(width, height)];// add yourEndPoint here
    UIColor *fill = [UIColor colorWithRed:0.80f green:0.80f blue:0.80f alpha:1.00f];
    shapelayer.strokeStart = 0.0;
    shapelayer.strokeColor = fill.CGColor;
    shapelayer.lineWidth = 1.5;
    shapelayer.lineJoin = kCALineJoinRound;
    shapelayer.lineDashPattern = [NSArray arrayWithObjects:[NSNumber numberWithInt:1],[NSNumber numberWithInt:3 ], nil];
    //    shapelayer.lineDashPhase = 3.0f;
    shapelayer.path = path.CGPath;
    
    [viewLayer addSublayer:shapelayer];
}
+ (void)setViewGradient:(UIView *)view
{
    
}
@end

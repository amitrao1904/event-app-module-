//
//  Constant.h
//  HealthOnPhone
//
//  Created by Akhilesh Mourya on 10/13/14.
//  Copyright (c) 2014 Akhilesh Mourya. All rights reserved.
//


//#import "image.h"

#ifdef DEBUG
#   define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#   define DLog(...)
#endif

#define SYSTEM_VERSION_LESS_THAN(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
//http://app.autodealrz.com/webservices/



#define BASE_URL           @"http://drvrsty.betaclubs.com/api/register/"
#define BASE_URLHOME       @"http://drvrsty.betaclubs.com/api/home/"
#define BASE_URLVEHICLE    @"http://drvrsty.betaclubs.com/api/vehicle/"
#define BASE_URLLOGIN      @"http://drvrsty.betaclubs.com/api/default/"
#define BASE_URLWEB        @"http://wowapps.in/motif_wow/webview/"
#define BASE_URL1          @"http://wowapps.in/motif_wow/Api/"

#define BASE_URL2     @"http://engineermaster.in/motif_wow/Api/"


#define VERIFYEMAILCODE             @"emailverify"
#define MOBILEREG                   @"signup"
#define COUNTRYCODELIST             @"index"
#define MOBILEOTP                   @"verifyotp"
#define FORGOT                      @"forgotpassword"
#define CHANGEPASSWORD              @"changepassword"
#define LOGIN                       @"login"
#define REGISTRATION                @"registration"
#define RESENDOTP                   @"resendotp"
#define PROFILE                     @"profile"
#define REGVEHICLE                  @"addvehicle"
#define WEB_URL_UserFbLogin         @"socialsignup"
#define WEB_URL_socialFbLogin       @"socialprofile"


//FEED API CALL

#define FEEDLIST                    @"index"



#define Feature_Product             @"slider_category.php"
#define AMCLIST                     @"json_sample_amc.php"
#define PRODUCTLIST                 @"json_sample_product_by_amc.php"


#define Json_ProductType            @"json_product_oftype.php"
#define Product_Detail              @"product_details.php"
#define Search                      @"search_product.php"
//#define JsonFilterCmdc            @"json_filter_by_cmdc.php"
#define JsonFilterCmdc              @"quotes.php"
#define Json_Orders_General         @"json_orders_general.php"



//#define Category1  @"cat_wise_subcat.php"







#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH,0)



#define serviceManager  [ServiceManager sharedClient]


#define RESPONSE_SUCCESS                @"success"
#define RESPONSE_SUCCESS_TRUE           @"1"
#define RESPONSE_STATUS                 @"status"
#define RESPONSE_ERROR                  @"errors"

#define RESPONSE_OK                     @"OK"
#define RESPONSE_ERROR_MESSAGE          @"message"
#define ALERT_ERROR_TITLE               @"Attention"



typedef NS_ENUM(NSUInteger, HTTPMethod) {
    GET,
    POST,
    PUT,
    DELETE,
    PATCH
};


typedef NS_ENUM(NSUInteger, TaskType)
{
    
    //kTasklogin,
    
    kTaskRegMobile,
    kTaskProfile,
    kTaskVerifyEmail,
    kTaskCountryCode,
    kTaskforgotpassword,
    kTaskChangePassword,
    kTaskotp,
    kTasklogin,
    kTaskRegVehicle,
    kTaskRegEmail,
    KTaskFbLogin,
    kTaskresendotp,
    kTasksocial,
    
    kTaskfeedlist,
    
    
        
};

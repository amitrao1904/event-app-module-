//
//  CALayer+ViewBorder.h
//  Farma
//
//  Created by Akhilesh Mourya on 03/10/15.
//  Copyright (c) 2015 admin. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface CALayer (ViewBorder)
@property(nonatomic, assign) UIColor* borderUIColor;
@end

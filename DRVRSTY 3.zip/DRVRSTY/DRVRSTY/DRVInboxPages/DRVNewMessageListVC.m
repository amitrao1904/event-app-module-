//
//  DRVNewMessageListVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVNewMessageListVC.h"
#import "DRVNewMessageCell.h"
@interface DRVNewMessageListVC ()
{
    DRVNewMessageCell *prototypeCell;
    
}
@end

@implementation DRVNewMessageListVC
@synthesize tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    def=[NSUserDefaults standardUserDefaults];
    
    array_list=[[NSMutableArray alloc]init];
    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method



#pragma mark - API Methods



#pragma mark - Action Method
-(IBAction)back:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}
-(IBAction)next_Action :(id)sender
{
    DRVNewMessageVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVNewMessageVC1"];
    [self.navigationController pushViewController:addinvController animated:YES];
}

- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender
{
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (DRVNewMessageCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([DRVNewMessageCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[DRVNewMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([DRVNewMessageCell class])];
    }
    prototypeCell.btn_select.layer.borderWidth = 1;
    prototypeCell.btn_select.layer.borderColor = [UIColor whiteColor].CGColor;
    //prototypeCell.btn_select.layer.cornerRadius=5;
    
    prototypeCell.btn_select.tag = indexPath.row;
    
    
    
    return prototypeCell;
}

#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

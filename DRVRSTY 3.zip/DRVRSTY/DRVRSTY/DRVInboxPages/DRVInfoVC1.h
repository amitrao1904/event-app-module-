//
//  DRVInfoVC1.h
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVInfoVC1 : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    NSMutableArray *array_list;
    NSUserDefaults *def;
    
}
@property (weak, nonatomic) IBOutlet UITextField *txt_search;
@property (weak, nonatomic) IBOutlet UIButton *btn_leaveconv;
@property (strong, nonatomic) IBOutlet UITableView *tblNew;

@end

//
//  DRVCustomInboxCell.m
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVCustomInboxCell.h"

@implementation DRVCustomInboxCell
@synthesize img_profile,label1,label2,label3;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

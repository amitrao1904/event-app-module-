//
//  DRVInboxVC.m
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import "DRVInboxVC.h"
#import "DRVCustomInboxCell.h"
@interface DRVInboxVC ()
{
    DRVCustomInboxCell *prototypeCell;
    
}
@end

@implementation DRVInboxVC
@synthesize txt_search,tblNew;
- (void)viewDidLoad {
    [super viewDidLoad];
    def=[NSUserDefaults standardUserDefaults];
    
    array_list1=[[NSMutableArray alloc]init];
    array_list2=[[NSMutableArray alloc]init];
    array_list3=[[NSMutableArray alloc]init];
    array_list4=[[NSMutableArray alloc]init];
    
    [array_list1 addObject:@"1"];
    [array_list1 addObject:@"2"];
    [array_list1 addObject:@"1"];
    [array_list1 addObject:@"2"];
    
    
    [array_list2 addObject:@"albrain_,druberrie"];
    [array_list2 addObject:@"druberrie"];
    [array_list2 addObject:@"albrain_"];
    [array_list2 addObject:@"druberrie"];
    
    
    [array_list3 addObject:@"12:53 PM"];
    [array_list3 addObject:@"9:42 AM"];
    [array_list3 addObject:@"MON"];
    [array_list3 addObject:@"14 MAR"];
    
    

    
    // Do any additional setup after loading the view.
}
#pragma mark - Custom Method


#pragma mark - API Methods


#pragma mark - Action Method
- (IBAction)menu_Action:(id)sender
{
    DRVSetting1VC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVSetting1VC"];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)edit_Action:(id)sender
{
//    DRVNewMessageListVC *registercontroller = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVNewMessageListVC"];
//    [self.navigationController pushViewController:registercontroller animated:true];
    
    
    DRVNewMessageListVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVNewMessageListVC"];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.45;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromTop;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    //self.navigationController.navigationBarHidden = NO;
    [self.navigationController pushViewController:addinvController animated:NO];
}

- (IBAction)mechnical_Action:(id)sender {
    
    DRVMobileMechanicVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVMobileMechanicVC1"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)search_Action:(id)sender {
    
    SearchJoinVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchJoinVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)globe_Action:(id)sender {
    
    DRVFeedVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVFeedVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)notification_Action:(id)sender {
    
    MyNotificationVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyNotificationVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}
- (IBAction)map_Action:(id)sender {
    
    MyMapVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyMapVC"];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.0;
    transition.type = kCATransitionFade;
    //transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:addinvController animated:NO];
}

#pragma mark - TableviewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [array_list1 count];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    prototypeCell = (DRVCustomInboxCell *)[tblNew dequeueReusableCellWithIdentifier:NSStringFromClass([DRVCustomInboxCell class])];
    
    if (prototypeCell == nil)
    {
        prototypeCell = [[DRVCustomInboxCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([DRVCustomInboxCell class])];
    }
    NSString *str=[array_list1 objectAtIndex:indexPath.row];
    
    prototypeCell.label1.text=[array_list2 objectAtIndex:indexPath.row];
    prototypeCell.label3.text=[array_list3 objectAtIndex:indexPath.row];
    
    if ([str isEqualToString:@"1"])
    {
        prototypeCell.img_profile.image=[UIImage imageNamed:@"hills1.jpeg"];
    }
    else
    {
    
       prototypeCell.img_profile.image=[UIImage imageNamed:@"hills2.jpeg"];
    
    }
    
    
    
    
    return prototypeCell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row==0)
    {
       
        
        DRVChatViewVC1 *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVChatViewVC1"];
        [self.navigationController pushViewController:addinvController animated:YES];
    }
    
    if (indexPath.row==1) {
        
        DRVChatViewVC *addinvController = [self.storyboard instantiateViewControllerWithIdentifier:@"DRVChatViewVC"];
        [self.navigationController pushViewController:addinvController animated:YES];

        
    }
    
    

}
#pragma mark - Memory CleanUP
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

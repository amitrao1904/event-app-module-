//
//  DRVInboxVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVInboxVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{

    NSMutableArray *array_list1;
    NSMutableArray *array_list2;
    NSMutableArray *array_list3;
    NSMutableArray *array_list4;
    NSUserDefaults *def;

}
@property (weak, nonatomic) IBOutlet UITextField *txt_search;

@property (strong, nonatomic) IBOutlet UITableView *tblNew;

@end

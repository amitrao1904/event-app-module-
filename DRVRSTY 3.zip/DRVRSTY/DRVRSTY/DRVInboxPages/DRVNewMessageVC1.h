//
//  DRVNewMessageVC1.h
//  DRVRSTY
//
//  Created by Macbook pro on 01/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVNewMessageVC1 : UIViewController<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate, UIActionSheetDelegate,UIScrollViewDelegate,UIDocumentInteractionControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{

    BOOL imageflag;
    UIImage *finalImage;
    NSData *dataImage;
    IBOutlet UIButton *postImage;
    NSData *imageData;
    NSData *eventImageData1;

}
@property (strong, nonatomic) IBOutlet UIImageView *imageview1;
@end

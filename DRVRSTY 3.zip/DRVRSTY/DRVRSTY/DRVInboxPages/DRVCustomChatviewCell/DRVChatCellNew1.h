//
//  DRVChatCellNew1.h
//  DRVRSTY
//
//  Created by Macbook pro on 10/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVChatCellNew1 : UITableViewCell
@property(strong,nonatomic) IBOutlet UIImageView *img_profile;
@property(strong,nonatomic) IBOutlet UILabel *lbl_msg;
@end

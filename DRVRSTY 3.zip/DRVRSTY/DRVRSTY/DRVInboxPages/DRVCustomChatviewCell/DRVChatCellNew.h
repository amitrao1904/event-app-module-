//
//  DRVChatCellNew.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVChatCellNew : UITableViewCell
@property(strong,nonatomic) IBOutlet UIImageView *img_profile;
@property(strong,nonatomic) IBOutlet UILabel *lbl_msg;
@end

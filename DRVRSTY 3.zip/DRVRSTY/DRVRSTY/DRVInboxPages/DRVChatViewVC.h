//
//  DRVChatViewVC.h
//  DRVRSTY
//
//  Created by Macbook pro on 05/05/17.
//  Copyright © 2017 Macbook pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DRVChatViewVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate, UIActionSheetDelegate,UIScrollViewDelegate,UIDocumentInteractionControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{

    NSMutableArray *messageee;
    NSMutableArray *userid;
    NSMutableArray *username;
    NSString *lbl_height;
    NSMutableArray *array_user;
    
    BOOL imageflag;
    UIImage *finalImage;
    NSData *dataImage;
    IBOutlet UIButton *postImage;
    NSData *imageData;
    NSData *eventImageData1;

}
@property(strong,nonatomic) IBOutlet UITableView *table_message;
@property (strong, nonatomic) IBOutlet UIImageView *imageview1;
@end
